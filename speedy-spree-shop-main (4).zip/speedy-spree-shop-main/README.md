# Green&Grace — Premium Grocery E-Commerce

A luxury grocery delivery web application built with React, Tailwind CSS, and Framer Motion. Designed to feel like a high-end lifestyle brand with smooth animations, elegant typography, and a premium visual identity.

![React](https://img.shields.io/badge/React-18-blue) ![Tailwind](https://img.shields.io/badge/Tailwind-3-06B6D4) ![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6) ![Framer Motion](https://img.shields.io/badge/Framer_Motion-11-FF0055)

## ✨ Features

- **Luxury UI** — Soft whites, warm beige, muted greens, gold accents
- **Glassmorphism** — Subtle blur effects on navigation and overlays
- **Smooth Animations** — Framer Motion scroll reveals, hover lifts, micro-interactions
- **Responsive** — Mobile-first design, elegant on all screen sizes
- **Serif + Sans Pairing** — Cormorant Garamond display + Inter body
- **REST API Architecture** — Edge Functions as backend, no direct DB access from client

## 🚀 Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| React 18 | UI framework |
| Tailwind CSS 3 | Utility-first styling |
| Framer Motion 11 | Animations & transitions |
| React Router 6 | Client-side routing |
| TanStack Query 5 | Data fetching & caching |
| Radix UI | Accessible primitives |
| Lucide React | Icon system |

## 🎨 Making It Your Own

### 1. Replace Branding
- Update logo in `src/components/Navbar.tsx` — replace "Green&Grace" with your brand
- Update footer in `src/pages/Index.tsx`
- Replace favicon in `public/favicon.ico`

### 2. Customize Colors
Edit `src/index.css` CSS variables:
```css
:root {
  --primary: 145 45% 28%;       /* Your brand green */
  --gold: 42 60% 60%;           /* Accent gold */
  --background: 40 30% 97%;     /* Base cream */
}
```

### 3. Change Fonts
Replace Google Fonts import in `src/index.css` and update `tailwind.config.ts` fontFamily.

### 4. Add Real Products
Replace mock data by connecting to your backend API. Update endpoints in `src/api/apiClient.ts`.

### 5. Remove Template Patterns
- Rename component files to match your domain
- Update page titles and meta descriptions in `index.html`
- Replace placeholder images with your photography

## 🏗️ Architecture

```
src/
├── api/          # API client & endpoint abstractions
├── components/   # Reusable UI components
├── contexts/     # Auth context
├── hooks/        # Custom React hooks
├── lib/          # Utilities
├── pages/        # Route pages
supabase/
├── functions/    # Edge Functions (REST API)
```

## 🔮 Future Enhancements

- **Payment Integration** — Stripe/Razorpay checkout
- **Auth System** — Social login, email verification
- **Real-time Tracking** — Live order status with maps
- **Search** — Full-text search with filters
- **Reviews** — Product ratings and reviews
- **Wishlist** — Save favourite products
