import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
}

async function getUser(req: Request) {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) return null;
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } }
    });
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) return null;
    return user.id;
  } catch (e) {
    console.error('getUser error:', e);
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const userId = await getUser(req);
  if (!userId) return jsonResponse({ error: 'Unauthorized' }, 401);

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('cart_items')
        .select('id, quantity, product_id, products(id, name, price, image, stock, unit)')
        .eq('user_id', userId);
      if (error) throw error;
      return jsonResponse(data || []);
    }

    if (req.method === 'POST') {
      const body = await req.json();
      if (!body.product_id) return jsonResponse({ error: 'Product ID is required' }, 400);

      const quantity = Math.max(1, Number(body.quantity) || 1);

      const { data: product } = await supabase.from('products').select('stock, name').eq('id', body.product_id).single();
      if (!product) return jsonResponse({ error: 'Product not found' }, 404);
      if (product.stock < quantity) return jsonResponse({ error: `Only ${product.stock} items available` }, 400);

      const { data: existing } = await supabase
        .from('cart_items')
        .select('id, quantity')
        .eq('user_id', userId)
        .eq('product_id', body.product_id)
        .maybeSingle();

      if (existing) {
        const newQty = existing.quantity + quantity;
        if (newQty > product.stock) return jsonResponse({ error: `Only ${product.stock} items available` }, 400);
        const { error } = await supabase.from('cart_items').update({ quantity: newQty }).eq('id', existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('cart_items').insert({ user_id: userId, product_id: body.product_id, quantity });
        if (error) throw error;
      }
      return jsonResponse({ success: true });
    }

    if (req.method === 'PUT') {
      const body = await req.json();
      if (!body.id) return jsonResponse({ error: 'Cart item ID is required' }, 400);

      const quantity = Number(body.quantity);
      if (isNaN(quantity)) return jsonResponse({ error: 'Invalid quantity' }, 400);

      if (quantity <= 0) {
        const { error } = await supabase.from('cart_items').delete().eq('id', body.id).eq('user_id', userId);
        if (error) throw error;
      } else {
        const { data: cartItem } = await supabase.from('cart_items').select('product_id').eq('id', body.id).eq('user_id', userId).single();
        if (!cartItem) return jsonResponse({ error: 'Cart item not found' }, 404);

        const { data: product } = await supabase.from('products').select('stock').eq('id', cartItem.product_id).single();
        if (product && quantity > product.stock) {
          return jsonResponse({ error: `Only ${product.stock} items available` }, 400);
        }

        const { error } = await supabase.from('cart_items').update({ quantity }).eq('id', body.id).eq('user_id', userId);
        if (error) throw error;
      }
      return jsonResponse({ success: true });
    }

    if (req.method === 'DELETE') {
      const reqUrl = new URL(req.url);
      const itemId = reqUrl.searchParams.get('id');
      const clearAll = reqUrl.searchParams.get('clear_all');

      if (clearAll === 'true') {
        const { error } = await supabase.from('cart_items').delete().eq('user_id', userId);
        if (error) throw error;
      } else if (itemId) {
        const { error } = await supabase.from('cart_items').delete().eq('id', itemId).eq('user_id', userId);
        if (error) throw error;
      } else {
        return jsonResponse({ error: 'Missing item id or clear_all flag' }, 400);
      }
      return jsonResponse({ success: true });
    }

    return jsonResponse({ error: 'Method not allowed' }, 405);
  } catch (e) {
    console.error('api-cart error:', e);
    return jsonResponse({ error: e.message || 'Internal server error' }, 500);
  }
});
