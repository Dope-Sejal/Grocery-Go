import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
}

async function getUser(req: Request) {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) return null;
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } }
    });
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) return null;
    return user.id;
  } catch (e) {
    console.error('getUser error:', e);
    return null;
  }
}

async function isAdmin(supabase: any, userId: string) {
  const { data } = await supabase.from('user_roles').select('role').eq('user_id', userId).eq('role', 'admin').maybeSingle();
  return !!data;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const userId = await getUser(req);
  if (!userId) return jsonResponse({ error: 'Unauthorized' }, 401);

  const url = new URL(req.url);
  const action = url.searchParams.get('action');

  try {
    if (req.method === 'GET') {
      if (action === 'all' && await isAdmin(supabase, userId)) {
        const { data, error } = await supabase
          .from('orders')
          .select('*, order_items(product_name, quantity, product_price), profiles!orders_user_id_fkey(name, email)')
          .order('created_at', { ascending: false });
        if (error) {
          const { data: d2, error: e2 } = await supabase
            .from('orders')
            .select('*, order_items(product_name, quantity, product_price)')
            .order('created_at', { ascending: false });
          if (e2) throw e2;
          return jsonResponse(d2 || []);
        }
        return jsonResponse(data || []);
      }

      if (action === 'analytics' && await isAdmin(supabase, userId)) {
        const [productsRes, ordersRes, profilesRes] = await Promise.all([
          supabase.from('products').select('id', { count: 'exact', head: true }),
          supabase.from('orders').select('id, total_price, order_status, created_at').order('created_at', { ascending: false }),
          supabase.from('profiles').select('id', { count: 'exact', head: true }),
        ]);
        const orders = ordersRes.data || [];
        const totalRevenue = orders.filter((o: any) => o.order_status !== 'cancelled').reduce((sum: number, o: any) => sum + Number(o.total_price), 0);
        const pendingOrders = orders.filter((o: any) => o.order_status === 'pending').length;
        return jsonResponse({
          totalProducts: productsRes.count || 0,
          totalOrders: orders.length,
          pendingOrders,
          totalRevenue,
          totalUsers: profilesRes.count || 0,
          recentOrders: orders.slice(0, 5),
        });
      }

      // User orders
      const { data, error } = await supabase
        .from('orders')
        .select('*, order_items(*, products(name, image))')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return jsonResponse(data || []);
    }

    if (req.method === 'POST') {
      const body = await req.json();
      if (!body.items || !Array.isArray(body.items) || body.items.length === 0) {
        return jsonResponse({ error: 'Order must have at least one item' }, 400);
      }
      if (!body.totalPrice || Number(body.totalPrice) <= 0) {
        return jsonResponse({ error: 'Invalid total price' }, 400);
      }

      const { data: order, error } = await supabase
        .from('orders')
        .insert({
          user_id: userId,
          total_price: Number(body.totalPrice),
          address: body.address || {},
          payment_method: body.paymentMethod || 'cod',
          payment_status: 'paid',
          tracking_status: 'order_placed',
        })
        .select()
        .single();
      if (error) throw error;

      const orderItems = body.items.map((item: any) => ({
        order_id: order.id,
        product_id: item.product_id || null,
        product_name: item.product_name || 'Unknown',
        product_price: Number(item.product_price) || 0,
        quantity: Number(item.quantity) || 1,
      }));
      const { error: itemsError } = await supabase.from('order_items').insert(orderItems);
      if (itemsError) throw itemsError;

      // Clear cart
      await supabase.from('cart_items').delete().eq('user_id', userId);
      return jsonResponse(order);
    }

    if (req.method === 'PUT') {
      const body = await req.json();
      const orderId = body.id || url.searchParams.get('id');
      if (!orderId) return jsonResponse({ error: 'Missing order id' }, 400);

      const admin = await isAdmin(supabase, userId);

      if (!admin) {
        const { data: existingOrder, error: fetchErr } = await supabase
          .from('orders')
          .select('user_id, order_status')
          .eq('id', orderId)
          .single();
        if (fetchErr || !existingOrder) return jsonResponse({ error: 'Order not found' }, 404);
        if (existingOrder.user_id !== userId) return jsonResponse({ error: 'Access denied' }, 403);
        if (existingOrder.order_status !== 'pending') {
          return jsonResponse({ error: 'Only pending orders can be cancelled' }, 400);
        }
        if (body.order_status && body.order_status !== 'cancelled') {
          return jsonResponse({ error: 'You can only cancel pending orders' }, 400);
        }
      }

      const updates: Record<string, any> = {};
      if (body.order_status) updates.order_status = body.order_status;
      if (body.tracking_status) updates.tracking_status = body.tracking_status;
      if (body.payment_status) updates.payment_status = body.payment_status;

      if (Object.keys(updates).length === 0) {
        return jsonResponse({ error: 'No updates provided' }, 400);
      }

      updates.updated_at = new Date().toISOString();

      const { error } = await supabase.from('orders').update(updates).eq('id', orderId);
      if (error) throw error;
      return jsonResponse({ success: true });
    }

    if (req.method === 'DELETE') {
      const orderId = url.searchParams.get('id');
      if (!orderId) return jsonResponse({ error: 'Missing order id' }, 400);

      const admin = await isAdmin(supabase, userId);
      if (!admin) {
        const { data: existingOrder, error: fetchErr } = await supabase
          .from('orders')
          .select('user_id, order_status')
          .eq('id', orderId)
          .single();
        if (fetchErr || !existingOrder) return jsonResponse({ error: 'Order not found' }, 404);
        if (existingOrder.user_id !== userId) return jsonResponse({ error: 'Access denied' }, 403);
        if (!['delivered', 'cancelled'].includes(existingOrder.order_status)) {
          return jsonResponse({ error: 'Only completed or cancelled orders can be deleted' }, 400);
        }
      }

      await supabase.from('order_items').delete().eq('order_id', orderId);
      const { error } = await supabase.from('orders').delete().eq('id', orderId);
      if (error) throw error;
      return jsonResponse({ success: true });
    }

    return jsonResponse({ error: 'Method not allowed' }, 405);
  } catch (e) {
    console.error('api-orders error:', e);
    return jsonResponse({ error: e.message || 'Internal server error' }, 500);
  }
});
