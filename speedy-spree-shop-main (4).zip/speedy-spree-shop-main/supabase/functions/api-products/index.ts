import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  const url = new URL(req.url);
  const id = url.searchParams.get('id');
  const categoryId = url.searchParams.get('category_id');
  const search = url.searchParams.get('search');

  try {
    if (req.method === 'GET') {
      if (id) {
        const { data, error } = await supabase
          .from('products')
          .select('*, categories(name)')
          .eq('id', id)
          .single();
        if (error) throw error;
        return new Response(JSON.stringify(data), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      let query = supabase.from('products').select('*, categories(name)');
      if (categoryId) query = query.eq('category_id', categoryId);
      if (search) query = query.ilike('name', `%${search}%`);
      const { data, error } = await query.order('name');
      if (error) throw error;
      return new Response(JSON.stringify(data || []), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // Auth check for mutations
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders });

    const userClient = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } }
    });
    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders });
    const userId = user.id;

    // Check admin
    const { data: roleData } = await supabase.from('user_roles').select('role').eq('user_id', userId).eq('role', 'admin').maybeSingle();
    if (!roleData) return new Response(JSON.stringify({ error: 'Admin required' }), { status: 403, headers: corsHeaders });

    if (req.method === 'POST') {
      const body = await req.json();
      if (!body.name || !String(body.name).trim()) {
        return new Response(JSON.stringify({ error: 'Product name is required' }), { status: 400, headers: corsHeaders });
      }
      if (!body.price || Number(body.price) <= 0) {
        return new Response(JSON.stringify({ error: 'Valid price is required' }), { status: 400, headers: corsHeaders });
      }
      const { data, error } = await supabase
        .from('products')
        .insert({
          name: String(body.name).trim(),
          description: body.description || null,
          price: Number(body.price),
          discount: Number(body.discount) || 0,
          category_id: body.category_id || null,
          image: body.image || null,
          stock: Number(body.stock) || 0,
          unit: body.unit || 'pc',
          is_best_seller: !!body.is_best_seller,
          is_deal_of_day: !!body.is_deal_of_day,
        })
        .select('*, categories(name)')
        .single();
      if (error) throw error;
      return new Response(JSON.stringify(data), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (req.method === 'PUT') {
      const body = await req.json();
      const productId = body.id || id;
      if (!productId) return new Response(JSON.stringify({ error: 'Missing id' }), { status: 400, headers: corsHeaders });
      const { id: _, categories: __, category_name: ___, ...updates } = body;
      const { error } = await supabase.from('products').update(updates).eq('id', productId);
      if (error) throw error;
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (req.method === 'DELETE') {
      const productId = url.searchParams.get('id');
      if (!productId) return new Response(JSON.stringify({ error: 'Missing id' }), { status: 400, headers: corsHeaders });
      
      // Remove related order_items references first (nullify product_id)
      await supabase.from('order_items').update({ product_id: null }).eq('product_id', productId);
      // Remove from cart_items
      await supabase.from('cart_items').delete().eq('product_id', productId);
      
      const { error } = await supabase.from('products').delete().eq('id', productId);
      if (error) throw error;
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: corsHeaders });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: corsHeaders });
  }
});
