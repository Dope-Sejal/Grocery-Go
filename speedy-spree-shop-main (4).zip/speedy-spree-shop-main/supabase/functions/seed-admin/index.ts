import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // Check if admin already exists
    const { data: existingUsers } = await supabase.auth.admin.listUsers();
    const adminExists = existingUsers?.users?.find(u => u.email === "admin@gmail.com");

    if (adminExists) {
      // Ensure admin role exists
      const { data: roleCheck } = await supabase
        .from("user_roles")
        .select("id")
        .eq("user_id", adminExists.id)
        .eq("role", "admin")
        .maybeSingle();

      if (!roleCheck) {
        await supabase.from("user_roles").upsert({
          user_id: adminExists.id,
          role: "admin",
        });
      }

      return new Response(JSON.stringify({ message: "Admin already exists", userId: adminExists.id }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create admin user
    const { data: newUser, error: createError } = await supabase.auth.admin.createUser({
      email: "admin@gmail.com",
      password: "admin123",
      email_confirm: true,
      user_metadata: { name: "Admin" },
    });

    if (createError) throw createError;

    // The handle_new_user trigger creates profile + 'user' role automatically
    // Now add admin role
    await supabase.from("user_roles").insert({
      user_id: newUser.user.id,
      role: "admin",
    });

    return new Response(JSON.stringify({ message: "Admin created successfully", userId: newUser.user.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
