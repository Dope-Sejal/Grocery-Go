
-- Add description to categories
ALTER TABLE public.categories ADD COLUMN IF NOT EXISTS description text;

-- Add best_seller and deal_of_day flags to products
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_best_seller boolean NOT NULL DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_deal_of_day boolean NOT NULL DEFAULT false;

-- Add tracking_status to orders for real-time tracking
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tracking_status text NOT NULL DEFAULT 'order_placed';
