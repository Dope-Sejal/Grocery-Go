
-- Add discount column to products
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS discount numeric DEFAULT 0;

-- Admin policies for products
CREATE POLICY "Admins can insert products" ON public.products FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update products" ON public.products FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete products" ON public.products FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'));

-- Admin policies for categories
CREATE POLICY "Admins can insert categories" ON public.categories FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update categories" ON public.categories FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete categories" ON public.categories FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'));

-- Allow users to delete their own delivered/cancelled orders
CREATE POLICY "Users can delete own completed orders" ON public.orders FOR DELETE TO authenticated USING (auth.uid() = user_id AND order_status IN ('delivered', 'cancelled'));
