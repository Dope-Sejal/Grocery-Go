import { useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { useProducts, useCategories } from '@/hooks/useProducts';
import { useState, useEffect } from 'react';

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryId = searchParams.get('category') || undefined;
  const searchQuery = searchParams.get('search') || '';
  const [search, setSearch] = useState(searchQuery);

  const { data: categories } = useCategories();
  const { data: products, isLoading } = useProducts(categoryId, search || undefined);

  useEffect(() => { setSearch(searchQuery); }, [searchQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams(prev => { if (search) prev.set('search', search); else prev.delete('search'); return prev; });
  };

  const setCategory = (catId?: string) => {
    setSearchParams(prev => { if (catId) prev.set('category', catId); else prev.delete('category'); return prev; });
  };

  const activeCategoryName = categories?.find(c => c.id === categoryId)?.name;

  return (
    <div className="container py-5 space-y-4 animate-fade-in">
      <div className="flex flex-col md:flex-row gap-3 items-start md:items-center justify-between">
        <div>
          <h1 className="font-display text-xl font-bold">{activeCategoryName || 'All Products'}</h1>
          <p className="text-xs text-muted-foreground">{products?.length || 0} products available</p>
        </div>
        <form onSubmit={handleSearch} className="w-full md:w-72">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10 h-9 text-sm rounded-lg" />
          </div>
        </form>
      </div>

      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
        <Button variant={!categoryId ? 'default' : 'outline'} size="sm"
          className={`rounded-full shrink-0 h-8 text-xs font-semibold ${!categoryId ? 'gradient-primary text-primary-foreground border-0' : ''}`}
          onClick={() => setCategory(undefined)}>All</Button>
        {categories?.map(cat => (
          <Button key={cat.id}
            variant={categoryId === cat.id ? 'default' : 'outline'}
            size="sm"
            className={`rounded-full shrink-0 h-8 text-xs font-semibold ${categoryId === cat.id ? 'gradient-primary text-primary-foreground border-0' : ''}`}
            onClick={() => setCategory(cat.id)}>{cat.name}</Button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="h-56 rounded-2xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : products?.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-muted-foreground text-sm">No products found</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {products?.map(p => (
            <ProductCard key={p.id} id={p.id} name={p.name} price={Number(p.price)} discount={Number(p.discount) || 0}
              image={p.image} unit={p.unit} stock={p.stock} categoryName={p.category_name}
              isBestSeller={(p as any).is_best_seller} isDealOfDay={(p as any).is_deal_of_day} />
          ))}
        </div>
      )}
    </div>
  );
}
