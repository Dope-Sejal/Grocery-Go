import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Plus, Trash2, Package, Users, ShoppingBag, LayoutGrid, BarChart3, IndianRupee, Clock, TrendingUp, Edit2, Save, X, Star, Zap, Image } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import * as productAPI from '@/api/productAPI';
import * as orderAPI from '@/api/orderAPI';
import * as userAPI from '@/api/userAPI';
import * as adminAPI from '@/api/adminAPI';

export default function Admin() {
  const { isAdmin, loading } = useAuth();
  const navigate = useNavigate();

  if (loading) return <div className="container py-20 text-center text-muted-foreground">Loading...</div>;
  if (!isAdmin) {
    return (
      <div className="container py-20 text-center space-y-4 animate-fade-in">
        <div className="h-16 w-16 mx-auto rounded-2xl bg-destructive/10 flex items-center justify-center">
          <Package className="h-8 w-8 text-destructive" />
        </div>
        <h2 className="font-display text-2xl font-bold">Access Denied</h2>
        <p className="text-muted-foreground text-sm">You need admin privileges to access this page.</p>
        <Button onClick={() => navigate('/')} className="rounded-xl">Go Home</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="container py-6 space-y-6">
        <div className="gradient-primary rounded-2xl p-6 text-primary-foreground">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-display text-2xl font-bold">Admin Dashboard</h1>
              <p className="text-xs opacity-80">Manage your store inventory & orders</p>
            </div>
            <Badge className="bg-primary-foreground/20 text-primary-foreground border-0 text-xs font-bold">Admin</Badge>
          </div>
        </div>

        <Tabs defaultValue="analytics">
          <TabsList className="grid w-full grid-cols-5 mb-4 h-11 rounded-xl bg-card border">
            <TabsTrigger value="analytics" className="text-xs gap-1 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><BarChart3 className="h-3.5 w-3.5" /> Analytics</TabsTrigger>
            <TabsTrigger value="products" className="text-xs gap-1 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><ShoppingBag className="h-3.5 w-3.5" /> Products</TabsTrigger>
            <TabsTrigger value="categories" className="text-xs gap-1 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><LayoutGrid className="h-3.5 w-3.5" /> Categories</TabsTrigger>
            <TabsTrigger value="orders" className="text-xs gap-1 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><Package className="h-3.5 w-3.5" /> Orders</TabsTrigger>
            <TabsTrigger value="users" className="text-xs gap-1 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><Users className="h-3.5 w-3.5" /> Users</TabsTrigger>
          </TabsList>

          <TabsContent value="analytics"><AdminAnalytics /></TabsContent>
          <TabsContent value="products"><AdminProducts /></TabsContent>
          <TabsContent value="categories"><AdminCategories /></TabsContent>
          <TabsContent value="orders"><AdminOrders /></TabsContent>
          <TabsContent value="users"><AdminUsers /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

const CHART_COLORS = ['hsl(262,83%,58%)', 'hsl(38,100%,55%)', 'hsl(217,91%,60%)', 'hsl(152,69%,45%)', 'hsl(0,84%,60%)'];

function AdminAnalytics() {
  const { data, isLoading } = useQuery({ queryKey: ['admin-analytics'], queryFn: adminAPI.fetchAnalytics });

  if (isLoading) return <div className="text-center py-10 text-muted-foreground text-sm">Loading analytics...</div>;
  if (!data) return null;

  const stats = [
    { label: 'Total Products', value: data.totalProducts, icon: ShoppingBag, color: 'from-primary/20 to-primary-glow/10' },
    { label: 'Total Orders', value: data.totalOrders, icon: Package, color: 'from-info/20 to-info/5' },
    { label: 'Pending', value: data.pendingOrders, icon: Clock, color: 'from-warning/20 to-warning/5' },
    { label: 'Revenue', value: `₹${data.totalRevenue.toLocaleString()}`, icon: IndianRupee, color: 'from-success/20 to-success/5' },
    { label: 'Users', value: data.totalUsers, icon: Users, color: 'from-accent to-accent/50' },
  ];

  const orderStatusData = [
    { name: 'Pending', value: data.recentOrders.filter((o: any) => o.order_status === 'pending').length },
    { name: 'Confirmed', value: data.recentOrders.filter((o: any) => o.order_status === 'confirmed').length },
    { name: 'Delivered', value: data.recentOrders.filter((o: any) => o.order_status === 'delivered').length },
    { name: 'Cancelled', value: data.recentOrders.filter((o: any) => o.order_status === 'cancelled').length },
  ].filter(d => d.value > 0);

  const revenueData = data.recentOrders.slice(0, 10).reverse().map((o: any, i: number) => ({ name: `#${i + 1}`, revenue: Number(o.total_price) }));

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {stats.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className={`bg-gradient-to-br ${color} border-0 shadow-card hover-lift`}>
            <CardContent className="p-4 space-y-2">
              <div className="h-9 w-9 rounded-xl gradient-primary flex items-center justify-center">
                <Icon className="h-4 w-4 text-primary-foreground" />
              </div>
              <p className="text-[11px] text-muted-foreground font-medium">{label}</p>
              <p className="font-display text-xl font-bold">{value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="border shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2"><TrendingUp className="h-4 w-4 text-primary" /> Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(262,83%,58%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(262,83%,58%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(240,13%,91%)" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Area type="monotone" dataKey="revenue" stroke="hsl(262,83%,58%)" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border shadow-card">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Order Status</CardTitle></CardHeader>
          <CardContent className="flex items-center justify-center">
            {orderStatusData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={orderStatusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} innerRadius={40} paddingAngle={4}>
                    {orderStatusData.map((_, index) => <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-muted-foreground">No order data</p>}
          </CardContent>
        </Card>
      </div>

      <Card className="border shadow-card">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Recent Orders</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2">
            {data.recentOrders.map((order: any) => (
              <div key={order.id} className="flex justify-between items-center text-xs border-b last:border-0 pb-2 last:pb-0">
                <div className="flex items-center gap-2">
                  <div className="h-7 w-7 rounded-lg gradient-primary flex items-center justify-center">
                    <Package className="h-3.5 w-3.5 text-primary-foreground" />
                  </div>
                  <span className="text-muted-foreground font-mono">#{order.id.slice(0, 8)}</span>
                </div>
                <Badge variant="outline" className="text-[10px] h-5">{order.order_status}</Badge>
                <span className="font-semibold">₹{Number(order.total_price).toFixed(0)}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AdminProducts() {
  const queryClient = useQueryClient();
  const { data: products } = useQuery({ queryKey: ['admin-products'], queryFn: () => productAPI.fetchProducts() });
  const { data: categories } = useQuery({ queryKey: ['categories'], queryFn: productAPI.fetchCategories });

  const [form, setForm] = useState({
    name: '', description: '', price: '', discount: '0', category_id: '', image: '', stock: '', unit: 'pc',
    is_best_seller: false, is_deal_of_day: false,
  });
  const [editId, setEditId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<any>({});

  const addProduct = useMutation({
    mutationFn: () => productAPI.createProduct({
      name: form.name, description: form.description, price: Number(form.price),
      discount: Number(form.discount), category_id: form.category_id || undefined,
      image: form.image || undefined, stock: Number(form.stock) || 0, unit: form.unit,
      is_best_seller: form.is_best_seller, is_deal_of_day: form.is_deal_of_day,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
      setForm({ name: '', description: '', price: '', discount: '0', category_id: '', image: '', stock: '', unit: 'pc', is_best_seller: false, is_deal_of_day: false });
      toast.success('Product added');
    },
    onError: (e) => toast.error(e.message),
  });

  const updateProduct = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => productAPI.updateProduct(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['admin-products'] }); setEditId(null); toast.success('Product updated'); },
    onError: (e) => toast.error(e.message),
  });

  const delProduct = useMutation({
    mutationFn: productAPI.deleteProduct,
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['admin-products'] }); queryClient.invalidateQueries({ queryKey: ['products'] }); toast.success('Deleted'); },
    onError: (e) => toast.error(e.message || 'Failed to delete product'),
  });

  const startEdit = (p: any) => {
    setEditId(p.id);
    setEditForm({ name: p.name, price: p.price, discount: p.discount || 0, stock: p.stock, is_best_seller: !!p.is_best_seller, is_deal_of_day: !!p.is_deal_of_day });
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <Card className="border shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Add Product</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            <Input placeholder="Name" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="text-sm h-9" />
            <Input placeholder="Price" type="number" value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))} className="text-sm h-9" />
            <Input placeholder="Discount %" type="number" value={form.discount} onChange={e => setForm(p => ({ ...p, discount: e.target.value }))} className="text-sm h-9" />
            <Input placeholder="Stock" type="number" value={form.stock} onChange={e => setForm(p => ({ ...p, stock: e.target.value }))} className="text-sm h-9" />
            <Select value={form.category_id} onValueChange={v => setForm(p => ({ ...p, category_id: v }))}>
              <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Category" /></SelectTrigger>
              <SelectContent>{categories?.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <Input placeholder="Image URL (optional)" value={form.image} onChange={e => setForm(p => ({ ...p, image: e.target.value }))} className="text-sm h-9" />
          <Input placeholder="Description" value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="text-sm h-9" />
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Switch checked={form.is_best_seller} onCheckedChange={v => setForm(p => ({ ...p, is_best_seller: v }))} />
              <Label className="text-xs flex items-center gap-1"><Star className="h-3 w-3 text-secondary" /> Best Seller</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.is_deal_of_day} onCheckedChange={v => setForm(p => ({ ...p, is_deal_of_day: v }))} />
              <Label className="text-xs flex items-center gap-1"><Zap className="h-3 w-3 text-destructive" /> Deal of the Day</Label>
            </div>
          </div>
          <Button onClick={() => addProduct.mutate()} disabled={!form.name || !form.price} size="sm" className="gap-1 rounded-lg gradient-primary text-primary-foreground border-0"><Plus className="h-3.5 w-3.5" /> Add Product</Button>
        </CardContent>
      </Card>

      <Card className="border shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Inventory ({products?.length || 0} products)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1.5">
            {products?.map(p => (
              <div key={p.id} className="flex items-center justify-between bg-muted/30 rounded-xl p-2.5 hover:bg-muted/50 transition-colors group">
                {editId === p.id ? (
                  <div className="flex-1 flex items-center gap-2 flex-wrap">
                    <Input value={editForm.name} onChange={e => setEditForm((f: any) => ({ ...f, name: e.target.value }))} className="h-8 text-xs w-32" />
                    <Input value={editForm.price} type="number" onChange={e => setEditForm((f: any) => ({ ...f, price: Number(e.target.value) }))} className="h-8 text-xs w-20" />
                    <Input value={editForm.stock} type="number" onChange={e => setEditForm((f: any) => ({ ...f, stock: Number(e.target.value) }))} className="h-8 text-xs w-20" />
                    <div className="flex items-center gap-2">
                      <Switch checked={editForm.is_best_seller} onCheckedChange={v => setEditForm((f: any) => ({ ...f, is_best_seller: v }))} />
                      <span className="text-[10px]">Best</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch checked={editForm.is_deal_of_day} onCheckedChange={v => setEditForm((f: any) => ({ ...f, is_deal_of_day: v }))} />
                      <span className="text-[10px]">Deal</span>
                    </div>
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-primary" onClick={() => updateProduct.mutate({ id: p.id, data: editForm })}>
                      <Save className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditId(null)}>
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-3">
                      <img src={p.image || ''} alt={p.name} className="h-9 w-9 rounded-lg object-cover bg-muted" />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="font-medium text-xs">{p.name}</p>
                          {(p as any).is_best_seller && <Star className="h-3 w-3 text-secondary fill-secondary" />}
                          {(p as any).is_deal_of_day && <Zap className="h-3 w-3 text-destructive fill-destructive" />}
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          ₹{p.price} {Number(p.discount) > 0 && `(${p.discount}% off)`} • Stock: {p.stock} • {p.category_name || 'Uncategorized'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => startEdit(p)}>
                        <Edit2 className="h-3.5 w-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => delProduct.mutate(p.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AdminCategories() {
  const queryClient = useQueryClient();
  const { data: categories } = useQuery({ queryKey: ['categories'], queryFn: productAPI.fetchCategories });
  const [form, setForm] = useState({ name: '', description: '', image: '' });
  const [editId, setEditId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<any>({});

  const addCategory = useMutation({
    mutationFn: () => productAPI.createCategory({ name: form.name, description: form.description, image: form.image }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      setForm({ name: '', description: '', image: '' });
      toast.success('Category added');
    },
    onError: (e) => toast.error(e.message),
  });

  const updateCat = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => productAPI.updateCategory(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['categories'] }); setEditId(null); toast.success('Updated'); },
    onError: (e) => toast.error(e.message),
  });

  const delCategory = useMutation({
    mutationFn: productAPI.deleteCategory,
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['categories'] }); queryClient.invalidateQueries({ queryKey: ['products'] }); queryClient.invalidateQueries({ queryKey: ['admin-products'] }); toast.success('Deleted'); },
    onError: (e) => toast.error(e.message || 'Failed to delete category'),
  });

  return (
    <div className="space-y-4 animate-fade-in">
      <Card className="border shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Add Category</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <Input placeholder="Category name" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="text-sm h-9" />
            <Input placeholder="Thumbnail URL (optional)" value={form.image} onChange={e => setForm(p => ({ ...p, image: e.target.value }))} className="text-sm h-9" />
          </div>
          <Input placeholder="Description (optional)" value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="text-sm h-9" />
          <Button onClick={() => addCategory.mutate()} disabled={!form.name} size="sm" className="gap-1 rounded-lg gradient-primary text-primary-foreground border-0">
            <Plus className="h-3.5 w-3.5" /> Add Category
          </Button>
        </CardContent>
      </Card>

      <Card className="border shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Categories ({categories?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {categories?.map(c => (
              <div key={c.id} className="flex items-center justify-between bg-muted/30 rounded-xl p-3 hover:bg-muted/50 transition-colors group">
                {editId === c.id ? (
                  <div className="flex-1 flex items-center gap-2 flex-wrap">
                    <Input value={editForm.name} onChange={e => setEditForm((f: any) => ({ ...f, name: e.target.value }))} className="h-8 text-xs w-28" placeholder="Name" />
                    <Input value={editForm.image || ''} onChange={e => setEditForm((f: any) => ({ ...f, image: e.target.value }))} className="h-8 text-xs w-40" placeholder="Image URL" />
                    <Input value={editForm.description || ''} onChange={e => setEditForm((f: any) => ({ ...f, description: e.target.value }))} className="h-8 text-xs flex-1" placeholder="Description" />
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-primary" onClick={() => updateCat.mutate({ id: c.id, data: editForm })}>
                      <Save className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditId(null)}>
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-3">
                      {c.image ? (
                        <img src={c.image} alt={c.name} className="h-9 w-9 rounded-lg object-cover" />
                      ) : (
                        <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center">
                          <Image className="h-4 w-4 text-accent-foreground" />
                        </div>
                      )}
                      <div>
                        <p className="font-medium text-xs">{c.name}</p>
                        {(c as any).description && <p className="text-[10px] text-muted-foreground line-clamp-1">{(c as any).description}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setEditId(c.id); setEditForm({ name: c.name, image: c.image || '', description: (c as any).description || '' }); }}>
                        <Edit2 className="h-3.5 w-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => delCategory.mutate(c.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AdminOrders() {
  const queryClient = useQueryClient();
  const { data: orders } = useQuery({ queryKey: ['admin-orders'], queryFn: orderAPI.fetchAllOrders });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => orderAPI.updateOrderStatus(id, status),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['admin-orders'] }); toast.success('Updated'); },
  });

  const updateTracking = useMutation({
    mutationFn: ({ id, tracking }: { id: string; tracking: string }) => orderAPI.updateTrackingStatus(id, tracking),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['admin-orders'] }); toast.success('Tracking updated'); },
  });

  return (
    <div className="space-y-3 animate-fade-in">
      <Card className="border shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">All Orders ({orders?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {orders?.map(order => (
              <div key={order.id} className="bg-muted/30 rounded-xl p-3 space-y-2 hover:bg-muted/50 transition-colors">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium text-xs font-mono">#{order.id.slice(0, 8)}</p>
                    <p className="text-[10px] text-muted-foreground">{new Date(order.created_at).toLocaleString()}</p>
                    {order.profiles && <p className="text-[10px] text-muted-foreground">By: {order.profiles.name || order.profiles.email}</p>}
                  </div>
                  <div className="flex gap-2">
                    <Select value={order.order_status} onValueChange={v => updateStatus.mutate({ id: order.id, status: v })}>
                      <SelectTrigger className="w-28 h-7 text-[10px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map(s => (
                          <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={order.tracking_status || 'order_placed'} onValueChange={v => updateTracking.mutate({ id: order.id, tracking: v })}>
                      <SelectTrigger className="w-36 h-7 text-[10px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {['order_placed', 'getting_ready', 'picked_up', 'out_for_delivery', 'delivered'].map(s => (
                          <SelectItem key={s} value={s} className="text-xs">{s.replace(/_/g, ' ')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <p className="text-xs">Total: <span className="font-bold">₹{Number(order.total_price).toFixed(0)}</span></p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AdminUsers() {
  const { data: profiles } = useQuery({ queryKey: ['admin-users'], queryFn: userAPI.fetchAllProfiles });

  return (
    <div className="animate-fade-in">
      <Card className="border shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Registered Users ({profiles?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1.5">
            {profiles?.map(p => (
              <div key={p.id} className="flex items-center justify-between bg-muted/30 rounded-xl p-2.5 hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
                    {(p.name || p.email || '?')[0].toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium text-xs">{p.name || 'No name'}</p>
                    <p className="text-[10px] text-muted-foreground">{p.email}</p>
                  </div>
                </div>
                <Badge variant="secondary" className="text-[10px]">{new Date(p.created_at).toLocaleDateString()}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
