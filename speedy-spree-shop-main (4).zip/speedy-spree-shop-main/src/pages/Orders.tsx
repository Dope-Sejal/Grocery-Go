import { useNavigate } from 'react-router-dom';
import { Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { OrderCard } from '@/components/OrderCard';
import { useOrders } from '@/hooks/useOrders';
import { useAuth } from '@/contexts/AuthContext';

export default function Orders() {
  const { user } = useAuth();
  const { orders, isLoading, cancelOrder, deleteOrder } = useOrders();
  const navigate = useNavigate();

  if (!user) {
    return (
      <div className="container py-20 text-center space-y-4">
        <Package className="h-16 w-16 mx-auto text-muted-foreground" />
        <h2 className="font-display text-2xl font-bold">Please login to view orders</h2>
        <Button onClick={() => navigate('/login')}>Login</Button>
      </div>
    );
  }

  if (isLoading) return <div className="container py-20 text-center text-muted-foreground">Loading...</div>;

  return (
    <div className="container py-6 max-w-2xl">
      <h1 className="font-display text-3xl font-bold mb-6">My Orders</h1>

      {orders.length === 0 ? (
        <div className="text-center py-20 space-y-4">
          <Package className="h-16 w-16 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">No orders yet</p>
          <Button onClick={() => navigate('/products')}>Start Shopping</Button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <OrderCard
              key={order.id}
              order={order as any}
              onCancel={(id) => cancelOrder.mutate(id)}
              onDelete={(id) => deleteOrder.mutate(id)}
              isCancelling={cancelOrder.isPending}
            />
          ))}
        </div>
      )}
    </div>
  );
}
