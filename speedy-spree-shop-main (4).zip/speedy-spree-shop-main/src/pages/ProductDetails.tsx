import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Minus, Plus, ShoppingCart, Shield, Truck, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useProduct } from '@/hooks/useProducts';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/contexts/AuthContext';
import { getDefaultImage } from '@/lib/defaultImages';
import { toast } from 'sonner';

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: product, isLoading } = useProduct(id!);
  const { user } = useAuth();
  const { cartItems, addToCart, updateQuantity } = useCart();

  if (isLoading) return <div className="container py-20 text-center text-muted-foreground text-sm">Loading...</div>;
  if (!product) return <div className="container py-20 text-center text-muted-foreground text-sm">Product not found</div>;

  const cartItem = cartItems.find(i => i.product_id === product.id);
  const discount = Number(product.discount) || 0;
  const finalPrice = discount > 0 ? Number(product.price) - (Number(product.price) * discount / 100) : Number(product.price);
  const displayImage = product.image || getDefaultImage(product.category_name);

  const handleAdd = () => {
    if (!user) { navigate('/login'); return; }
    if (cartItem) {
      updateQuantity.mutate({ itemId: cartItem.id, quantity: cartItem.quantity + 1 });
    } else {
      addToCart.mutate({ productId: product.id });
    }
  };

  const handleDecrease = () => {
    if (!cartItem) return;
    if (cartItem.quantity <= 1) {
      toast.info('Minimum quantity is 1. Use remove button to delete.');
      return;
    }
    updateQuantity.mutate({ itemId: cartItem.id, quantity: cartItem.quantity - 1 });
  };

  return (
    <div className="container py-5 max-w-4xl animate-fade-in">
      <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="mb-3 text-xs">
        <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Back
      </Button>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="relative aspect-square rounded-3xl bg-muted/20 p-6 flex items-center justify-center overflow-hidden border">
          <img
            src={displayImage}
            alt={product.name}
            className="max-h-full object-contain"
            onError={(e) => { (e.target as HTMLImageElement).src = '/placeholder.svg'; }}
          />
          {discount > 0 && (
            <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground text-sm font-bold px-3 py-1 rounded-xl">
              {discount}% OFF
            </Badge>
          )}
        </div>

        <div className="space-y-4">
          {product.category_name && (
            <Badge variant="secondary" className="text-[10px] font-semibold">{product.category_name}</Badge>
          )}
          <h1 className="font-display text-2xl font-bold">{product.name}</h1>
          <p className="text-sm text-muted-foreground">{product.description || 'Fresh and high quality product.'}</p>

          <div className="flex items-baseline gap-2">
            <span className="font-display text-3xl font-extrabold text-primary">₹{Math.round(finalPrice)}</span>
            {discount > 0 && (
              <span className="text-base text-muted-foreground line-through">₹{Number(product.price)}</span>
            )}
            <span className="text-xs text-muted-foreground">/ {product.unit || 'pc'}</span>
          </div>

          {discount > 0 && (
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 text-xs">
              You save ₹{Math.round(Number(product.price) - finalPrice)}
            </Badge>
          )}

          <p className="text-xs">
            {product.stock > 0 ? (
              <span className="text-primary font-semibold">In Stock ({product.stock} available)</span>
            ) : (
              <span className="text-destructive font-semibold">Out of Stock</span>
            )}
          </p>

          {product.stock > 0 && (
            <div className="flex items-center gap-3 pt-2">
              {cartItem ? (
                <>
                  <div className="flex items-center gap-2 border border-primary rounded-xl px-1 bg-primary/5">
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-9 w-9"
                      disabled={cartItem.quantity <= 1}
                      onClick={handleDecrease}
                    >
                      <Minus className="h-4 w-4 text-primary" />
                    </Button>
                    <span className="w-8 text-center font-bold text-primary">{cartItem.quantity}</span>
                    <Button size="icon" variant="ghost" className="h-9 w-9" onClick={handleAdd}>
                      <Plus className="h-4 w-4 text-primary" />
                    </Button>
                  </div>
                  <Button onClick={() => navigate('/cart')} className="flex-1 rounded-xl h-10 font-bold text-sm">
                    <ShoppingCart className="mr-2 h-4 w-4" /> Go to Cart
                  </Button>
                </>
              ) : (
                <Button size="lg" className="flex-1 rounded-xl h-11 font-bold" onClick={handleAdd}>
                  <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
                </Button>
              )}
            </div>
          )}

          {/* Promises */}
          <div className="grid grid-cols-3 gap-2 pt-4 border-t">
            {[
              { icon: Truck, text: 'Free Delivery' },
              { icon: Clock, text: '10 min delivery' },
              { icon: Shield, text: 'Best Quality' },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex flex-col items-center gap-1 p-2 rounded-xl bg-muted/30 text-center">
                <Icon className="h-4 w-4 text-primary" />
                <span className="text-[10px] font-medium">{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
