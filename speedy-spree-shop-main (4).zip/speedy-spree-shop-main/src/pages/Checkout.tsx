import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Wallet, Banknote, Smartphone, MapPin, Tag, CheckCircle, X, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/useCart';
import { useOrders } from '@/hooks/useOrders';
import { useAuth } from '@/contexts/AuthContext';
import { PAYMENT_METHODS } from '@/api/paymentAPI';
import { LocationMap } from '@/components/LocationMap';
import { applyCoupon, AVAILABLE_COUPONS } from '@/lib/coupons';
import { toast } from 'sonner';

const iconMap: Record<string, React.ElementType> = {
  'banknote': Banknote,
  'credit-card': CreditCard,
  'wallet': Wallet,
  'smartphone': Smartphone,
};

export default function Checkout() {
  const { user } = useAuth();
  const { cartItems, totalPrice } = useCart();
  const { placeOrder } = useOrders();
  const navigate = useNavigate();

  const [address, setAddress] = useState({ full_address: '', city: '', state: '', zip_code: '' });
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [loading, setLoading] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ discount: number; message: string } | null>(null);
  const [upiConfirmed, setUpiConfirmed] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!user) { navigate('/login'); return null; }
  if (cartItems.length === 0) { navigate('/cart'); return null; }

  const handleLocationSelect = (location: { full_address: string; city: string; state: string; zip_code: string }) => {
    setAddress({
      full_address: location.full_address,
      city: location.city,
      state: location.state,
      zip_code: location.zip_code,
    });
  };

  const handleApplyCoupon = () => {
    const result = applyCoupon(couponCode, totalPrice);
    if (result.valid) {
      setAppliedCoupon({ discount: result.discount, message: result.message });
      toast.success(result.message);
    } else {
      toast.error(result.message);
      setAppliedCoupon(null);
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
  };

  const handleCopyUPI = () => {
    navigator.clipboard.writeText('admin@upi').then(() => {
      setCopied(true);
      toast.success('UPI ID copied!');
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const finalTotal = appliedCoupon ? totalPrice - appliedCoupon.discount : totalPrice;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.full_address.trim()) { toast.error('Please select your delivery address'); return; }
    if (paymentMethod === 'upi' && !upiConfirmed) { toast.error('Please confirm your UPI payment first'); return; }

    setLoading(true);
    try {
      const items = cartItems.map(item => ({
        product_id: item.product_id,
        product_name: item.products?.name || 'Unknown',
        product_price: item.products?.price || 0,
        quantity: item.quantity,
      }));
      await placeOrder.mutateAsync({ items, totalPrice: finalTotal, address, paymentMethod });
      navigate('/orders');
    } catch {
      // error handled by mutation
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container py-6 max-w-2xl animate-fade-in">
      <h1 className="font-display text-2xl font-bold mb-5">Checkout</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Location Map */}
        <div className="bg-card rounded-2xl border p-4 space-y-3">
          <h2 className="font-display font-semibold text-sm flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary" /> Select Delivery Location
          </h2>
          <LocationMap onLocationSelect={handleLocationSelect} />
        </div>

        {/* Address */}
        <div className="bg-card rounded-2xl border p-4 space-y-3">
          <h2 className="font-display font-semibold text-sm">Delivery Address</h2>
          <div className="space-y-2">
            <div>
              <Label htmlFor="address" className="text-xs">Full Address</Label>
              <Input id="address" placeholder="House/Flat, Street, Landmark" value={address.full_address}
                onChange={e => setAddress(p => ({ ...p, full_address: e.target.value }))} required className="text-sm h-9" />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <Label htmlFor="city" className="text-xs">City</Label>
                <Input id="city" placeholder="City" value={address.city}
                  onChange={e => setAddress(p => ({ ...p, city: e.target.value }))} className="text-sm h-9" />
              </div>
              <div>
                <Label htmlFor="state" className="text-xs">State</Label>
                <Input id="state" placeholder="State" value={address.state}
                  onChange={e => setAddress(p => ({ ...p, state: e.target.value }))} className="text-sm h-9" />
              </div>
              <div>
                <Label htmlFor="zip" className="text-xs">ZIP</Label>
                <Input id="zip" placeholder="ZIP" value={address.zip_code}
                  onChange={e => setAddress(p => ({ ...p, zip_code: e.target.value }))} className="text-sm h-9" />
              </div>
            </div>
          </div>
        </div>

        {/* Coupon */}
        <div className="bg-card rounded-2xl border p-4 space-y-3">
          <h2 className="font-display font-semibold text-sm flex items-center gap-2">
            <Tag className="h-4 w-4 text-primary" /> Apply Coupon
          </h2>
          {appliedCoupon ? (
            <div className="flex items-center justify-between bg-primary/5 border border-primary/20 rounded-lg px-3 py-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-primary" />
                <div>
                  <p className="text-xs font-semibold text-primary">{couponCode.toUpperCase()} applied</p>
                  <p className="text-[11px] text-muted-foreground">{appliedCoupon.message}</p>
                </div>
              </div>
              <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={handleRemoveCoupon}>
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Input
                placeholder="Enter coupon code"
                value={couponCode}
                onChange={e => setCouponCode(e.target.value)}
                className="text-sm h-9 uppercase"
              />
              <Button type="button" variant="outline" size="sm" onClick={handleApplyCoupon} disabled={!couponCode.trim()} className="shrink-0 h-9 text-xs font-semibold">
                Apply
              </Button>
            </div>
          )}
          <div className="flex gap-2 flex-wrap">
            {AVAILABLE_COUPONS.map(c => (
              <button
                type="button"
                key={c.code}
                onClick={() => { setCouponCode(c.code); }}
                className="text-[10px] font-semibold border border-dashed border-primary/40 text-primary px-2 py-1 rounded-md hover:bg-primary/5 transition-colors"
              >
                {c.code} — {c.description}
              </button>
            ))}
          </div>
        </div>

        {/* Payment */}
        <div className="bg-card rounded-2xl border p-4 space-y-3">
          <h2 className="font-display font-semibold text-sm">Payment Method</h2>
          <RadioGroup value={paymentMethod} onValueChange={v => { setPaymentMethod(v); setUpiConfirmed(false); }} className="space-y-1.5">
            {PAYMENT_METHODS.map(({ id, label, description, icon }) => {
              const Icon = iconMap[icon] || Banknote;
              return (
                <label key={id} className={`flex items-center gap-3 p-2.5 rounded-xl border cursor-pointer transition-all duration-200 ${paymentMethod === id ? 'border-primary bg-primary/5 shadow-sm' : 'hover:bg-muted/50'}`}>
                  <RadioGroupItem value={id} />
                  <Icon className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <span className="font-medium text-xs block">{label}</span>
                    <span className="text-[10px] text-muted-foreground">{description}</span>
                  </div>
                </label>
              );
            })}
          </RadioGroup>

          {/* UPI Payment Section */}
          {paymentMethod === 'upi' && (
            <div className="mt-3 rounded-xl border-2 border-dashed border-primary/40 bg-primary/5 p-4 space-y-3">
              <h3 className="text-sm font-semibold text-primary flex items-center gap-2">
                <Smartphone className="h-4 w-4" /> Pay via UPI
              </h3>
              <p className="text-xs text-muted-foreground">
                Send <strong className="text-foreground">₹{Math.round(finalTotal)}</strong> to the UPI ID below:
              </p>
              <div className="flex items-center gap-2 bg-card rounded-lg border p-3">
                <span className="font-mono font-bold text-sm text-primary flex-1">admin@upi</span>
                <Button type="button" variant="outline" size="sm" className="h-8 text-xs gap-1" onClick={handleCopyUPI}>
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                  {copied ? 'Copied' : 'Copy'}
                </Button>
              </div>
              <p className="text-[10px] text-muted-foreground">
                After sending payment, click the button below to confirm.
              </p>
              {upiConfirmed ? (
                <div className="flex items-center gap-2 text-primary text-xs font-semibold">
                  <CheckCircle className="h-4 w-4" /> Payment confirmed! Proceed to place order.
                </div>
              ) : (
                <Button
                  type="button"
                  onClick={() => { setUpiConfirmed(true); toast.success('Payment confirmed!'); }}
                  className="w-full rounded-xl h-10 font-bold text-sm bg-primary text-primary-foreground"
                >
                  ✅ I have paid ₹{Math.round(finalTotal)}
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Summary */}
        <div className="bg-card rounded-2xl border p-4 space-y-2">
          <h2 className="font-display font-semibold text-sm">Bill Details</h2>
          {cartItems.map(item => (
            <div key={item.id} className="flex justify-between text-xs">
              <span className="text-muted-foreground">{item.products?.name || 'Item'} x{item.quantity}</span>
              <span>₹{((item.products?.price || 0) * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div className="flex justify-between text-xs pt-1 border-t">
            <span className="text-muted-foreground">Subtotal</span>
            <span>₹{totalPrice.toFixed(2)}</span>
          </div>
          {appliedCoupon && (
            <div className="flex justify-between text-xs text-primary font-medium">
              <span>Coupon Discount</span>
              <span>-₹{Math.round(appliedCoupon.discount)}</span>
            </div>
          )}
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">Delivery</span>
            <span className="text-primary font-medium">FREE</span>
          </div>
          <div className="flex justify-between font-display font-bold text-base pt-2 border-t">
            <span>Total</span>
            <span>₹{Math.round(finalTotal)}</span>
          </div>
        </div>

        <Button type="submit" size="lg" className="w-full rounded-xl h-12 font-bold text-sm" disabled={loading || (paymentMethod === 'upi' && !upiConfirmed)}>
          {loading ? 'Placing Order...' : `Place Order • ₹${Math.round(finalTotal)}`}
        </Button>
      </form>
    </div>
  );
}
