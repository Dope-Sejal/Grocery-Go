import { useNavigate, Link } from 'react-router-dom';
import { ShoppingBag, ArrowRight, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CartItemComponent } from '@/components/CartItem';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/contexts/AuthContext';

export default function Cart() {
  const { user } = useAuth();
  const { cartItems, isLoading, updateQuantity, removeFromCart, totalPrice } = useCart();
  const navigate = useNavigate();

  if (!user) {
    return (
      <div className="container py-20 text-center space-y-4 animate-fade-in">
        <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground" />
        <h2 className="font-display text-2xl font-bold">Please login to view cart</h2>
        <Button onClick={() => navigate('/login')} className="rounded-xl">Login</Button>
      </div>
    );
  }

  if (isLoading) return <div className="container py-20 text-center text-muted-foreground text-sm">Loading...</div>;

  if (cartItems.length === 0) {
    return (
      <div className="container py-20 text-center space-y-4 animate-fade-in">
        <div className="h-20 w-20 mx-auto rounded-3xl bg-muted flex items-center justify-center">
          <ShoppingBag className="h-10 w-10 text-muted-foreground" />
        </div>
        <h2 className="font-display text-xl font-bold">Your cart is empty</h2>
        <p className="text-sm text-muted-foreground">Add some products to get started</p>
        <Button asChild className="rounded-xl"><Link to="/products">Browse Products</Link></Button>
      </div>
    );
  }

  return (
    <div className="container py-5 max-w-2xl animate-fade-in">
      <h1 className="font-display text-xl font-bold mb-4">Your Cart ({cartItems.length} items)</h1>

      <div className="bg-card rounded-2xl border p-4">
        {cartItems.map(item => (
          <CartItemComponent
            key={item.id}
            item={item}
            onUpdateQuantity={(id, qty) => updateQuantity.mutate({ itemId: id, quantity: qty })}
            onRemove={(id) => removeFromCart.mutate(id)}
          />
        ))}
      </div>

      {/* Coupon hint */}
      <div className="mt-3 flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-xl px-3 py-2">
        <Tag className="h-4 w-4 text-primary" />
        <p className="text-xs text-primary font-medium">Apply coupon at checkout — use <strong>SAVE10</strong> or <strong>WELCOME20</strong></p>
      </div>

      <div className="mt-4 bg-card rounded-2xl border p-4 space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Subtotal</span>
          <span>₹{totalPrice.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Delivery</span>
          <span className="text-primary font-semibold">FREE</span>
        </div>
        <div className="flex justify-between font-display font-bold text-base pt-2 border-t">
          <span>Total</span>
          <span>₹{totalPrice.toFixed(2)}</span>
        </div>
        <Button className="w-full mt-2 rounded-xl h-11 font-bold text-sm" onClick={() => navigate('/checkout')}>
          Proceed to Checkout <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
