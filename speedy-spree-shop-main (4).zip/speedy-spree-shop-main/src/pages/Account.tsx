import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Package, MapPin, Lock, Phone, LogOut, MessageSquare, ChevronRight, Mail, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders } from '@/hooks/useOrders';
import { OrderCard } from '@/components/OrderCard';
import { supabase } from '@/integrations/supabase/client';
import { apiGet, apiPost, apiPut, apiDelete } from '@/api/apiClient';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function Account() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="container py-6 max-w-3xl space-y-6 animate-fade-in">
        {/* Header */}
        <div className="gradient-primary rounded-2xl p-6 text-primary-foreground">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-full bg-primary-foreground/20 flex items-center justify-center text-2xl font-bold">
              {(user.email?.[0] || 'U').toUpperCase()}
            </div>
            <div>
              <h1 className="font-display text-xl font-bold">My Account</h1>
              <p className="text-sm opacity-80">{user.email}</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="profile" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4 h-11 rounded-xl bg-card border">
            <TabsTrigger value="profile" className="text-xs gap-1.5 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><User className="h-3.5 w-3.5" /> Profile</TabsTrigger>
            <TabsTrigger value="orders" className="text-xs gap-1.5 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><Package className="h-3.5 w-3.5" /> Orders</TabsTrigger>
            <TabsTrigger value="addresses" className="text-xs gap-1.5 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><MapPin className="h-3.5 w-3.5" /> Addresses</TabsTrigger>
            <TabsTrigger value="security" className="text-xs gap-1.5 rounded-lg data-[state=active]:gradient-primary data-[state=active]:text-primary-foreground"><Shield className="h-3.5 w-3.5" /> Security</TabsTrigger>
          </TabsList>

          <TabsContent value="profile"><ProfileSection userId={user.id} /></TabsContent>
          <TabsContent value="orders"><OrdersSection /></TabsContent>
          <TabsContent value="addresses"><AddressesSection userId={user.id} /></TabsContent>
          <TabsContent value="security"><SecuritySection onSignOut={signOut} /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function ProfileSection({ userId }: { userId: string }) {
  const queryClient = useQueryClient();
  const { data: profile, isLoading } = useQuery({
    queryKey: ['profile', userId],
    queryFn: () => apiGet<any>('api-users', { action: 'profile' }),
  });

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [initialized, setInitialized] = useState(false);

  if (profile && !initialized) {
    setName(profile.name || '');
    setPhone(profile.phone || '');
    setInitialized(true);
  }

  const updateProfile = useMutation({
    mutationFn: () => apiPut('api-users', { name, phone }, { action: 'profile' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      toast.success('Profile updated');
    },
    onError: (e) => toast.error(e.message),
  });

  if (isLoading) return <div className="text-center py-10 text-muted-foreground text-sm">Loading...</div>;

  return (
    <Card className="border shadow-card">
      <CardHeader>
        <CardTitle className="text-sm font-semibold flex items-center gap-2"><User className="h-4 w-4 text-primary" /> Profile Details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-xs">Full Name</Label>
            <Input value={name} onChange={e => setName(e.target.value)} className="h-9 text-sm" />
          </div>
          <div>
            <Label className="text-xs">Phone Number</Label>
            <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+91 9876543210" className="h-9 text-sm" />
          </div>
        </div>
        <div>
          <Label className="text-xs">Email</Label>
          <Input value={profile?.email || ''} disabled className="h-9 text-sm bg-muted/50" />
        </div>
        <Button onClick={() => updateProfile.mutate()} className="gradient-primary text-primary-foreground rounded-xl h-10 text-sm font-semibold">
          Save Changes
        </Button>
      </CardContent>
    </Card>
  );
}

function OrdersSection() {
  const { orders, isLoading, cancelOrder, deleteOrder } = useOrders();

  if (isLoading) return <div className="text-center py-10 text-muted-foreground text-sm">Loading...</div>;

  return (
    <div className="space-y-3">
      {orders.length === 0 ? (
        <Card className="border shadow-card">
          <CardContent className="py-12 text-center">
            <Package className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">No orders yet</p>
          </CardContent>
        </Card>
      ) : (
        orders.map(order => (
          <OrderCard
            key={order.id}
            order={order as any}
            onCancel={(id) => cancelOrder.mutate(id)}
            onDelete={(id) => deleteOrder.mutate(id)}
          />
        ))
      )}
    </div>
  );
}

function AddressesSection({ userId }: { userId: string }) {
  const queryClient = useQueryClient();
  const { data: addresses = [], isLoading } = useQuery({
    queryKey: ['addresses', userId],
    queryFn: () => apiGet<any[]>('api-users', { action: 'addresses' }),
  });

  const [form, setForm] = useState({ full_address: '', city: '', state: '', zip_code: '', label: 'Home' });

  const addAddress = useMutation({
    mutationFn: () => apiPost('api-users', form, { action: 'address' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['addresses'] });
      setForm({ full_address: '', city: '', state: '', zip_code: '', label: 'Home' });
      toast.success('Address added');
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteAddress = useMutation({
    mutationFn: (id: string) => apiDelete('api-users', { action: 'address', id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['addresses'] });
      toast.success('Address removed');
    },
  });

  if (isLoading) return <div className="text-center py-10 text-muted-foreground text-sm">Loading...</div>;

  return (
    <div className="space-y-4">
      <Card className="border shadow-card">
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> Add Address</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Input placeholder="Full Address" value={form.full_address} onChange={e => setForm(p => ({ ...p, full_address: e.target.value }))} className="h-9 text-sm" />
          <div className="grid grid-cols-3 gap-2">
            <Input placeholder="City" value={form.city} onChange={e => setForm(p => ({ ...p, city: e.target.value }))} className="h-9 text-sm" />
            <Input placeholder="State" value={form.state} onChange={e => setForm(p => ({ ...p, state: e.target.value }))} className="h-9 text-sm" />
            <Input placeholder="ZIP" value={form.zip_code} onChange={e => setForm(p => ({ ...p, zip_code: e.target.value }))} className="h-9 text-sm" />
          </div>
          <Button onClick={() => addAddress.mutate()} disabled={!form.full_address} className="gradient-primary text-primary-foreground rounded-xl h-9 text-sm font-semibold">
            Add Address
          </Button>
        </CardContent>
      </Card>

      {addresses.map((addr: any) => (
        <Card key={addr.id} className="border shadow-card">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl bg-accent flex items-center justify-center">
                <MapPin className="h-4 w-4 text-accent-foreground" />
              </div>
              <div>
                <p className="text-xs font-semibold">{addr.label || 'Address'}</p>
                <p className="text-[11px] text-muted-foreground">{addr.full_address}</p>
                <p className="text-[10px] text-muted-foreground">{[addr.city, addr.state, addr.zip_code].filter(Boolean).join(', ')}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" className="text-destructive text-xs" onClick={() => deleteAddress.mutate(addr.id)}>Remove</Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function SecuritySection({ onSignOut }: { onSignOut: () => Promise<void> }) {
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChangePassword = async () => {
    if (newPassword.length < 6) { toast.error('Min 6 characters'); return; }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setLoading(false);
    if (error) toast.error(error.message);
    else { toast.success('Password updated'); setNewPassword(''); }
  };

  return (
    <div className="space-y-4">
      <Card className="border shadow-card">
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><Lock className="h-4 w-4 text-primary" /> Change Password</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Input type="password" placeholder="New password (min 6 chars)" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="h-9 text-sm" />
          <Button onClick={handleChangePassword} disabled={loading} className="gradient-primary text-primary-foreground rounded-xl h-9 text-sm font-semibold">
            {loading ? 'Updating...' : 'Update Password'}
          </Button>
        </CardContent>
      </Card>

      <Card className="border shadow-card border-destructive/20">
        <CardContent className="p-4">
          <Button variant="destructive" className="w-full rounded-xl h-10 font-semibold" onClick={() => onSignOut()}>
            <LogOut className="h-4 w-4 mr-2" /> Sign Out
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
