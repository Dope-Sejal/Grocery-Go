import { Link } from 'react-router-dom';
import { ArrowRight, Leaf, Shield, Truck, Clock, Star, Sparkles, Zap, Gift, Heart, TrendingUp, Send, Phone, Mail, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CategoryList } from '@/components/CategoryList';
import { ProductCard } from '@/components/ProductCard';
import { useProducts } from '@/hooks/useProducts';
import { motion } from 'framer-motion';
import { useState } from 'react';

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] },
};
const stagger = { animate: { transition: { staggerChildren: 0.1 } } };

const Index = () => {
  const { data: products, isLoading } = useProducts();
  const bestSellers = products?.filter(p => (p as any).is_best_seller).slice(0, 8) || [];
  const deals = products?.filter(p => (p as any).is_deal_of_day || Number(p.discount) > 0).slice(0, 8) || [];
  const featured = products?.slice(0, 8) || [];
  const [email, setEmail] = useState('');

  return (
    <div className="min-h-screen overflow-hidden">
      {/* ===== HERO ===== */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 gradient-hero animate-gradient opacity-95" />
        <div className="absolute top-10 left-10 w-[400px] h-[400px] blob-yellow rounded-full animate-blob opacity-40" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] blob-lime rounded-full animate-blob opacity-30" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 w-[300px] h-[300px] blob-green rounded-full animate-breathe opacity-20" />

        <div className="container relative z-10">
          <motion.div className="max-w-2xl mx-auto text-center space-y-8" initial="initial" animate="animate" variants={stagger}>
            <motion.div variants={fadeUp}>
              <span className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/20 backdrop-blur-sm px-5 py-2.5 text-xs font-semibold text-primary-foreground border border-primary-foreground/20">
                <Sparkles className="h-3.5 w-3.5" /> Fresh Groceries • Lightning Fast
              </span>
            </motion.div>

            <motion.h1 variants={fadeUp} className="font-display text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.05] text-primary-foreground drop-shadow-lg">
              Fresh Food,{' '}
              <span className="relative inline-block">
                <span className="relative z-10">Happy Life</span>
                <span className="absolute bottom-1 left-0 right-0 h-3 bg-secondary/50 -skew-x-3 rounded" />
              </span>
            </motion.h1>

            <motion.p variants={fadeUp} className="text-base md:text-lg text-primary-foreground/85 max-w-lg mx-auto leading-relaxed font-medium">
              Farm-fresh produce, artisan goods, and everyday essentials — delivered to your door in minutes.
            </motion.p>

            <motion.div variants={fadeUp} className="flex gap-4 justify-center flex-wrap">
              <Button size="lg" asChild className="rounded-full px-10 bg-secondary text-secondary-foreground shadow-luxury hover:shadow-elevated hover:scale-105 transition-all h-14 text-base font-extrabold border-0">
                <Link to="/products">
                  🛒 Shop Now <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ===== PROMISE BAR ===== */}
      <section className="relative -mt-7 z-20">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-card rounded-2xl shadow-elevated border border-border/50 p-5">
            <div className="flex items-center justify-center gap-6 md:gap-14 overflow-x-auto scrollbar-hide">
              {[
                { icon: Leaf, text: 'Farm Fresh', color: 'text-green' },
                { icon: Shield, text: 'Quality Assured', color: 'text-teal' },
                { icon: Clock, text: '10-Min Delivery', color: 'text-orange' },
                { icon: Truck, text: 'Free Over ₹500', color: 'text-primary' },
              ].map(({ icon: Icon, text, color }) => (
                <div key={text} className="flex items-center gap-2.5 shrink-0">
                  <div className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center">
                    <Icon className={`h-4.5 w-4.5 ${color}`} />
                  </div>
                  <span className="text-xs font-semibold text-foreground whitespace-nowrap">{text}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ===== PROMO BANNERS ===== */}
      <section className="py-10 mt-4">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { icon: Zap, title: 'Flash Deals', desc: 'Up to 50% off today', gradient: 'gradient-sunny', link: '/products', cta: 'Grab Now', ctaClass: 'bg-green-deep text-primary-foreground hover:bg-green' },
              { icon: Gift, title: 'Gift Hampers', desc: 'Curated organic selections', gradient: 'gradient-primary', link: '/products', cta: 'Explore', ctaClass: 'bg-primary-foreground/20 text-primary-foreground border border-primary-foreground/30 hover:bg-primary-foreground/30' },
              { icon: Heart, title: 'Daily Fresh', desc: 'Farm-to-table produce', gradient: 'gradient-fresh', link: '/products', cta: 'Shop Fresh', ctaClass: 'bg-secondary text-secondary-foreground hover:scale-105' },
            ].map((b, i) => (
              <motion.div key={b.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1, duration: 0.6 }}
                className={`rounded-2xl p-7 relative overflow-hidden group cursor-pointer hover:shadow-elevated transition-all duration-500 ${b.gradient} text-primary-foreground`}>
                <div className="absolute top-0 right-0 w-40 h-40 bg-primary-foreground/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700" />
                <b.icon className="h-8 w-8 mb-3 opacity-80" />
                <h3 className="font-display text-xl font-bold">{b.title}</h3>
                <p className="text-sm opacity-80 mt-1">{b.desc}</p>
                <Button size="sm" asChild className={`mt-4 rounded-full text-xs font-bold border-0 shadow-sm transition-all ${b.ctaClass}`}>
                  <Link to={b.link}>{b.cta}</Link>
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CATEGORIES ===== */}
      <section className="py-10 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-lime-soft/30 to-background" />
        <div className="container relative space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl gradient-candy flex items-center justify-center shadow-sm">
                <Sparkles className="h-5 w-5 text-secondary-foreground" />
              </div>
              <div>
                <h2 className="font-display text-2xl font-bold">Shop by Category</h2>
                <p className="text-sm text-muted-foreground">Browse our curated collections</p>
              </div>
            </div>
            <Link to="/products" className="text-xs text-primary font-bold hover:underline underline-offset-4 flex items-center gap-1">View all <ArrowRight className="h-3 w-3" /></Link>
          </div>
          <CategoryList />
        </div>
      </section>

      {/* ===== HOT DEALS ===== */}
      {deals.length > 0 && (
        <section className="py-10 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-soft/50 via-lime-soft/30 to-yellow-soft/50" />
          <div className="container relative space-y-6">
            <motion.div initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl gradient-warm flex items-center justify-center shadow-sm animate-pulse-glow">
                <Zap className="h-5 w-5 text-secondary-foreground" />
              </div>
              <div>
                <h2 className="font-display text-2xl font-bold">Today's Hot Deals 🔥</h2>
                <p className="text-xs text-muted-foreground">Limited time offers, grab them fast!</p>
              </div>
            </motion.div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {deals.map(p => (
                <ProductCard key={p.id} id={p.id} name={p.name} price={Number(p.price)} discount={Number(p.discount) || 0} image={p.image} unit={p.unit} stock={p.stock} categoryName={p.category_name} isDealOfDay={(p as any).is_deal_of_day} isBestSeller={(p as any).is_best_seller} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ===== TRENDING STRIP ===== */}
      <section className="py-6">
        <div className="container">
          <div className="rounded-2xl gradient-fresh animate-gradient p-6 md:p-8 flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3 text-primary-foreground">
              <TrendingUp className="h-7 w-7" />
              <div>
                <h3 className="font-display font-bold text-xl">🌿 Trending This Week</h3>
                <p className="text-xs opacity-80">Most popular items among our customers</p>
              </div>
            </div>
            <Button asChild className="rounded-full bg-secondary text-secondary-foreground font-extrabold px-8 border-0 shadow-sm hover:scale-105 transition-transform text-sm h-11">
              <Link to="/products">View Trending <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ===== BEST SELLERS ===== */}
      {bestSellers.length > 0 && (
        <section className="py-10 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-green/5 via-teal/5 to-lime/5" />
          <div className="container relative space-y-6">
            <motion.div initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl gradient-sunny flex items-center justify-center shadow-sm">
                <Star className="h-5 w-5 text-secondary-foreground" />
              </div>
              <div>
                <h2 className="font-display text-2xl font-bold">Customer Favorites ⭐</h2>
                <p className="text-xs text-muted-foreground">Our most loved products</p>
              </div>
            </motion.div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {bestSellers.map(p => (
                <ProductCard key={p.id} id={p.id} name={p.name} price={Number(p.price)} discount={Number(p.discount) || 0} image={p.image} unit={p.unit} stock={p.stock} categoryName={p.category_name} isBestSeller />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ===== STATS ===== */}
      <section className="py-10">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { value: '10K+', label: 'Happy Customers', gradient: 'gradient-primary', icon: '😊' },
              { value: '500+', label: 'Fresh Products', gradient: 'gradient-sunny', icon: '🛍️' },
              { value: '10min', label: 'Avg Delivery', gradient: 'gradient-nature', icon: '⚡' },
              { value: '4.9★', label: 'App Rating', gradient: 'gradient-warm', icon: '⭐' },
            ].map((stat, i) => (
              <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className={`rounded-2xl p-6 text-center ${stat.gradient} text-primary-foreground shadow-card hover:shadow-elevated transition-all duration-500 hover:-translate-y-1`}>
                <span className="text-3xl mb-2 block">{stat.icon}</span>
                <h3 className="font-display text-3xl font-extrabold">{stat.value}</h3>
                <p className="text-xs opacity-80 mt-1 font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== ALL PRODUCTS ===== */}
      <section className="py-10 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-green/3 to-background" />
        <div className="container relative space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl gradient-nature flex items-center justify-center shadow-sm">
                <Sparkles className="h-5 w-5 text-primary-foreground" />
              </div>
              <h2 className="font-display text-2xl font-bold">Daily Fresh Picks</h2>
            </div>
            <Link to="/products" className="text-xs text-primary font-bold hover:underline underline-offset-4 flex items-center gap-1">See all <ArrowRight className="h-3 w-3" /></Link>
          </div>
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-72 rounded-2xl bg-muted/50 shimmer" />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {featured.map(p => (
                <ProductCard key={p.id} id={p.id} name={p.name} price={Number(p.price)} discount={Number(p.discount) || 0} image={p.image} unit={p.unit} stock={p.stock} categoryName={p.category_name} isBestSeller={(p as any).is_best_seller} isDealOfDay={(p as any).is_deal_of_day} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section className="py-16">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
            className="rounded-3xl gradient-fresh animate-gradient p-12 md:p-16 text-center relative overflow-hidden">
            <div className="absolute top-0 left-1/4 w-60 h-60 bg-primary-foreground/5 rounded-full blur-3xl animate-breathe" />
            <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-secondary/10 rounded-full blur-3xl animate-blob" />
            <div className="relative z-10 max-w-lg mx-auto space-y-6">
              <span className="text-5xl">🥦</span>
              <h2 className="font-display text-3xl md:text-4xl font-extrabold text-primary-foreground">Start Saving Today</h2>
              <p className="text-sm text-primary-foreground/85 leading-relaxed font-medium">
                Join thousands of happy customers. Fresh groceries, amazing prices, delivered fast.
              </p>
              <Button size="lg" asChild className="rounded-full px-10 bg-secondary text-secondary-foreground shadow-luxury hover:shadow-elevated hover:scale-105 transition-all h-14 text-base font-extrabold border-0">
                <Link to="/products">🛒 Start Shopping</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ===== PREMIUM FOOTER ===== */}
      <footer className="relative overflow-hidden">
        {/* Dark gradient background */}
        <div className="absolute inset-0 gradient-dark" />
        <div className="absolute inset-0 bg-gradient-to-t from-green-deep/40 to-transparent" />

        <div className="container relative z-10 pt-16 pb-8">
          {/* Newsletter strip */}
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="rounded-2xl gradient-fresh p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6 mb-14 shadow-elevated">
            <div className="text-center md:text-left">
              <h3 className="font-display text-2xl font-extrabold text-primary-foreground flex items-center gap-2">
                <Mail className="h-6 w-6" /> Stay Fresh, Stay Updated
              </h3>
              <p className="text-sm text-primary-foreground/80 mt-1">Get exclusive deals and fresh picks delivered to your inbox</p>
            </div>
            <form onSubmit={e => { e.preventDefault(); setEmail(''); }} className="flex gap-2 w-full md:w-auto">
              <Input placeholder="Enter your email" value={email} onChange={e => setEmail(e.target.value)}
                className="bg-primary-foreground/20 border-primary-foreground/30 text-primary-foreground placeholder:text-primary-foreground/50 rounded-full h-12 px-5 w-full md:w-72 backdrop-blur-sm" />
              <Button type="submit" className="rounded-full h-12 px-6 bg-secondary text-secondary-foreground font-bold border-0 shadow-sm hover:scale-105 transition-transform shrink-0">
                <Send className="h-4 w-4 mr-1" /> Subscribe
              </Button>
            </form>
          </motion.div>

          {/* Footer grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="h-9 w-9 rounded-lg gradient-primary flex items-center justify-center shadow-sm">
                  <span className="text-primary-foreground text-lg">🥬</span>
                </div>
                <h4 className="font-display text-lg font-bold text-primary-foreground/90">GroceryGo</h4>
              </div>
              <p className="text-xs text-primary-foreground/50 leading-relaxed">
                Premium grocery delivery. Farm-fresh produce and artisan goods, delivered in minutes to your doorstep.
              </p>
              {/* Social icons */}
              <div className="flex gap-3 mt-4">
                {['𝕏', 'f', 'in', '▶'].map((s, i) => (
                  <div key={i} className="h-8 w-8 rounded-full bg-primary-foreground/10 flex items-center justify-center text-xs text-primary-foreground/60 hover:bg-primary-foreground/20 hover:text-primary-foreground transition-all cursor-pointer">
                    {s}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h5 className="text-xs font-bold uppercase tracking-[0.15em] text-primary-foreground/40 mb-4">Shop</h5>
              <ul className="space-y-2.5">
                {['All Products', 'Categories', 'Best Sellers', 'Daily Deals'].map(t => (
                  <li key={t}><Link to="/products" className="text-sm text-primary-foreground/55 hover:text-secondary transition-colors font-medium">{t}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <h5 className="text-xs font-bold uppercase tracking-[0.15em] text-primary-foreground/40 mb-4">Account</h5>
              <ul className="space-y-2.5">
                {[{ t: 'My Profile', l: '/account' }, { t: 'Orders', l: '/orders' }, { t: 'Cart', l: '/cart' }, { t: 'Wishlist', l: '/products' }].map(i => (
                  <li key={i.t}><Link to={i.l} className="text-sm text-primary-foreground/55 hover:text-secondary transition-colors font-medium">{i.t}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <h5 className="text-xs font-bold uppercase tracking-[0.15em] text-primary-foreground/40 mb-4">Contact Us</h5>
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-sm text-primary-foreground/55">
                  <Phone className="h-3.5 w-3.5 text-secondary/70" /> +91 98765 43210
                </li>
                <li className="flex items-center gap-2 text-sm text-primary-foreground/55">
                  <Mail className="h-3.5 w-3.5 text-secondary/70" /> help@grocerygo.com
                </li>
                <li className="flex items-start gap-2 text-sm text-primary-foreground/55">
                  <MapPin className="h-3.5 w-3.5 text-secondary/70 mt-0.5" /> 123 Fresh St, Mumbai, IN
                </li>
              </ul>
            </div>
          </div>

          <div className="h-px bg-gradient-to-r from-transparent via-primary-foreground/10 to-transparent" />
          <div className="flex flex-col md:flex-row items-center justify-between mt-6 gap-2">
            <p className="text-xs text-primary-foreground/35 font-medium">© 2026 GroceryGo. All rights reserved.</p>
            <div className="flex gap-4">
              {['Privacy Policy', 'Terms of Service', 'Shipping'].map(t => (
                <span key={t} className="text-xs text-primary-foreground/35 hover:text-primary-foreground/60 transition-colors cursor-pointer">{t}</span>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
