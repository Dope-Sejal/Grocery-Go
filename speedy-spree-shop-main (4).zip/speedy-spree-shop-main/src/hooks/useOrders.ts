import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import * as orderAPI from '@/api/orderAPI';

export function useOrders() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['orders', user?.id],
    queryFn: () => orderAPI.fetchUserOrders(user!.id),
    enabled: !!user,
    retry: 2,
    retryDelay: 1000,
  });

  const placeOrder = useMutation({
    mutationFn: async ({ items, totalPrice, address, paymentMethod }: {
      items: { product_id: string; product_name: string; product_price: number; quantity: number }[];
      totalPrice: number;
      address: object;
      paymentMethod: string;
    }) => {
      if (!user) throw new Error('Please login');
      return orderAPI.placeOrder({ userId: user.id, items, totalPrice, address, paymentMethod });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['cart'] });
      toast.success('Order placed successfully!');
    },
    onError: (e) => toast.error(e.message),
  });

  const cancelOrder = useMutation({
    mutationFn: async (orderId: string) => {
      await orderAPI.cancelOrder(orderId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      toast.success('Order cancelled');
    },
    onError: (e) => toast.error(e.message || 'Failed to cancel order'),
  });

  const deleteOrderMutation = useMutation({
    mutationFn: async (orderId: string) => {
      await orderAPI.deleteOrder(orderId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      toast.success('Order removed from history');
    },
    onError: (e) => toast.error(e.message || 'Failed to delete order'),
  });

  return { orders, isLoading, placeOrder, cancelOrder, deleteOrder: deleteOrderMutation };
}
