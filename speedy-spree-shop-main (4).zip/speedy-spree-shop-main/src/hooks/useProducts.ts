import { useQuery } from '@tanstack/react-query';
import { fetchCategories, fetchProducts, fetchProduct } from '@/api/productAPI';

export function useCategories() {
  return useQuery({
    queryKey: ['categories'],
    queryFn: fetchCategories,
  });
}

export function useProducts(categoryId?: string, search?: string) {
  return useQuery({
    queryKey: ['products', categoryId, search],
    queryFn: () => fetchProducts(categoryId, search),
  });
}

export function useProduct(id: string) {
  return useQuery({
    queryKey: ['product', id],
    queryFn: () => fetchProduct(id),
    enabled: !!id,
  });
}
