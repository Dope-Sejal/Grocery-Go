import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { apiGet, apiPost, apiPut, apiDelete } from '@/api/apiClient';

export interface CartItemWithProduct {
  id: string;
  quantity: number;
  product_id: string;
  products: {
    id: string;
    name: string;
    price: number;
    image: string | null;
    stock: number;
    unit: string | null;
  };
}

export function useCart() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ['cart', user?.id],
    queryFn: async () => {
      if (!user) return [];
      return apiGet<CartItemWithProduct[]>('api-cart');
    },
    enabled: !!user,
    retry: 2,
    retryDelay: 1000,
  });

  const addToCart = useMutation({
    mutationFn: async ({ productId, quantity = 1 }: { productId: string; quantity?: number }) => {
      if (!user) throw new Error('Please login first');
      await apiPost('api-cart', { product_id: productId, quantity: Math.max(1, quantity) });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cart'] });
      toast.success('Added to cart');
    },
    onError: (e) => toast.error(e.message),
  });

  const updateQuantity = useMutation({
    mutationFn: async ({ itemId, quantity }: { itemId: string; quantity: number }) => {
      const safeQty = Math.max(1, Math.round(quantity));
      if (isNaN(safeQty)) throw new Error('Invalid quantity');
      await apiPut('api-cart', { id: itemId, quantity: safeQty });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['cart'] }),
    onError: (e) => toast.error(e.message),
  });

  const removeFromCart = useMutation({
    mutationFn: async (itemId: string) => {
      await apiDelete('api-cart', { id: itemId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cart'] });
      toast.success('Removed from cart');
    },
    onError: (e) => toast.error(e.message),
  });

  const clearCart = useMutation({
    mutationFn: async () => {
      if (!user) return;
      await apiDelete('api-cart', { clear_all: 'true' });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['cart'] }),
  });

  const totalItems = cartItems.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const totalPrice = cartItems.reduce((sum, item) => sum + (item.quantity || 0) * (item.products?.price || 0), 0);

  return { cartItems, isLoading, addToCart, updateQuantity, removeFromCart, clearCart, totalItems, totalPrice };
}
