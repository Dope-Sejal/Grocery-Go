import { apiGet, apiPost, apiPut, apiDelete } from './apiClient';
import { Order } from './types';

export async function fetchUserOrders(userId: string): Promise<Order[]> {
  return apiGet<Order[]>('api-orders');
}

export async function fetchAllOrders(): Promise<any[]> {
  return apiGet<any[]>('api-orders', { action: 'all' });
}

export async function placeOrder(params: {
  userId: string;
  items: { product_id: string; product_name: string; product_price: number; quantity: number }[];
  totalPrice: number;
  address: object;
  paymentMethod: string;
}): Promise<Order> {
  return apiPost<Order>('api-orders', {
    items: params.items,
    totalPrice: params.totalPrice,
    address: params.address,
    paymentMethod: params.paymentMethod,
  });
}

export async function cancelOrder(orderId: string): Promise<void> {
  await apiPut('api-orders', { id: orderId, order_status: 'cancelled' });
}

export async function deleteOrder(orderId: string): Promise<void> {
  await apiDelete('api-orders', { id: orderId });
}

export async function updateOrderStatus(orderId: string, status: string): Promise<void> {
  await apiPut('api-orders', { id: orderId, order_status: status });
}

export async function updateTrackingStatus(orderId: string, trackingStatus: string): Promise<void> {
  await apiPut('api-orders', { id: orderId, tracking_status: trackingStatus });
}
