/**
 * API Helper — calls edge functions with retry logic and resilient error handling.
 */

import { supabase } from '@/integrations/supabase/client';

const PROJECT_ID = import.meta.env.VITE_SUPABASE_PROJECT_ID;
const BASE = `https://${PROJECT_ID}.supabase.co/functions/v1`;

async function getAuthHeaders(): Promise<Record<string, string>> {
  const { data: { session } } = await supabase.auth.getSession();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (session?.access_token) {
    headers['Authorization'] = `Bearer ${session.access_token}`;
  }
  return headers;
}

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const text = await res.text();
    let message = 'Request failed';
    try {
      const json = JSON.parse(text);
      message = json.error || message;
    } catch {
      if (text.includes('521') || text.includes('Web server is down')) {
        message = 'Server temporarily unavailable. Please try again in a moment.';
      } else if (text.includes('<!DOCTYPE') || text.includes('<html')) {
        message = 'Server error. Please try again.';
      }
    }
    throw new Error(message);
  }
  const text = await res.text();
  if (!text) return {} as T;
  try {
    return JSON.parse(text);
  } catch {
    return {} as T;
  }
}

async function fetchWithRetry(url: string, options: RequestInit, retries = 2): Promise<Response> {
  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetch(url, options);
      // Retry on 521 (server down) or 502/503
      if ((res.status === 521 || res.status === 502 || res.status === 503) && i < retries) {
        await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        continue;
      }
      return res;
    } catch (err) {
      if (i < retries) {
        await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        continue;
      }
      throw new Error('Network error. Please check your connection and try again.');
    }
  }
  throw new Error('Request failed after retries');
}

function buildUrl(fn: string, params?: Record<string, string>): string {
  const url = new URL(`${BASE}/${fn}`);
  if (params) Object.entries(params).forEach(([k, v]) => { if (v != null) url.searchParams.set(k, v); });
  return url.toString();
}

async function apiGet<T>(fn: string, params?: Record<string, string>): Promise<T> {
  const res = await fetchWithRetry(buildUrl(fn, params), { headers: await getAuthHeaders() });
  return handleResponse<T>(res);
}

async function apiPost<T>(fn: string, body: any, params?: Record<string, string>): Promise<T> {
  const res = await fetchWithRetry(buildUrl(fn, params), {
    method: 'POST', headers: await getAuthHeaders(), body: JSON.stringify(body),
  });
  return handleResponse<T>(res);
}

async function apiPut<T>(fn: string, body: any, params?: Record<string, string>): Promise<T> {
  const res = await fetchWithRetry(buildUrl(fn, params), {
    method: 'PUT', headers: await getAuthHeaders(), body: JSON.stringify(body),
  });
  return handleResponse<T>(res);
}

async function apiDelete(fn: string, params?: Record<string, string>): Promise<void> {
  const res = await fetchWithRetry(buildUrl(fn, params), {
    method: 'DELETE', headers: await getAuthHeaders(),
  });
  if (!res.ok) {
    const text = await res.text();
    let message = 'Request failed';
    try { const json = JSON.parse(text); message = json.error || message; } catch {
      if (text.includes('521')) message = 'Server temporarily unavailable. Please try again.';
    }
    throw new Error(message);
  }
}

export { apiGet, apiPost, apiPut, apiDelete, getAuthHeaders, BASE };
