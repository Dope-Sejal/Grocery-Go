/**
 * Admin API Layer — calls edge functions instead of direct DB access.
 */

import { apiGet } from './apiClient';
import { AdminAnalytics } from './types';

export async function fetchAnalytics(): Promise<AdminAnalytics> {
  return apiGet<AdminAnalytics>('api-orders', { action: 'analytics' });
}
