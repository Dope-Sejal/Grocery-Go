import { apiGet, apiPost, apiPut, apiDelete } from './apiClient';
import { Product, Category } from './types';
import { getDefaultImage } from '@/lib/defaultImages';

// ============ Categories ============

export async function fetchCategories(): Promise<Category[]> {
  return apiGet<Category[]>('api-categories');
}

export async function createCategory(params: { name: string; description?: string; image?: string }): Promise<Category> {
  return apiPost<Category>('api-categories', params);
}

export async function updateCategory(id: string, updates: { name?: string; description?: string; image?: string }): Promise<void> {
  await apiPut('api-categories', { id, ...updates });
}

export async function deleteCategory(id: string): Promise<void> {
  await apiDelete('api-categories', { id });
}

// ============ Products ============

function enrichProduct(p: any): Product {
  return {
    ...p,
    discount: Number(p.discount) || 0,
    category_name: p.categories?.name,
    image: p.image || getDefaultImage(p.categories?.name),
  };
}

export async function fetchProducts(categoryId?: string, search?: string): Promise<Product[]> {
  const params: Record<string, string> = {};
  if (categoryId) params.category_id = categoryId;
  if (search) params.search = search;
  const data = await apiGet<any[]>('api-products', params);
  return data.map(enrichProduct);
}

export async function fetchProduct(id: string): Promise<Product> {
  const data = await apiGet<any>('api-products', { id });
  return enrichProduct(data);
}

export async function createProduct(product: {
  name: string; description?: string; price: number; discount?: number;
  category_id?: string; image?: string; stock?: number; unit?: string;
  is_best_seller?: boolean; is_deal_of_day?: boolean;
}): Promise<Product> {
  const data = await apiPost<any>('api-products', product);
  return enrichProduct(data);
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<void> {
  await apiPut('api-products', { id, ...updates });
}

export async function deleteProduct(id: string): Promise<void> {
  await apiDelete('api-products', { id });
}
