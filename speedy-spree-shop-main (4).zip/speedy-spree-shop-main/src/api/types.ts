// API Types - structured for future MongoDB migration
// Replace these interfaces with MongoDB document types when migrating

export interface Product {
  id: string;
  name: string;
  price: number;
  discount: number;
  stock: number;
  unit: string | null;
  description: string | null;
  image: string | null;
  category_id: string | null;
  category_name?: string;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  image: string | null;
  created_at: string;
}

export interface CartItem {
  id: string;
  quantity: number;
  product_id: string;
  product: Product;
}

export interface Order {
  id: string;
  user_id: string;
  total_price: number;
  order_status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_method: string | null;
  address: Record<string, any>;
  created_at: string;
  updated_at: string;
  order_items: OrderItem[];
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  product_name: string;
  product_price: number;
  quantity: number;
}

export interface UserProfile {
  id: string;
  user_id: string;
  name: string;
  email: string;
  phone: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface PaymentMethod {
  id: string;
  label: string;
  type: 'cod' | 'upi' | 'card' | 'wallet';
  icon: string;
  description: string;
  gateway?: 'razorpay' | 'stripe' | 'paypal';
}

export interface Address {
  id: string;
  user_id: string;
  label: string | null;
  full_address: string;
  city: string | null;
  state: string | null;
  zip_code: string | null;
  is_default: boolean | null;
}

export interface AdminAnalytics {
  totalProducts: number;
  totalOrders: number;
  pendingOrders: number;
  totalRevenue: number;
  totalUsers: number;
  recentOrders: Order[];
}
