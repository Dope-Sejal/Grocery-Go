/**
 * Payment API Layer
 * Currently uses mock payment processing.
 * Replace with real payment gateway integrations when migrating.
 * 
 * Supported gateways for future integration:
 * - Razorpay (UPI, Cards, Wallets)
 * - Stripe (Cards, Wallets)
 * - PayPal (Wallet)
 */

import { PaymentMethod } from './types';

export const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'cod',
    label: 'Cash on Delivery',
    type: 'cod',
    icon: 'banknote',
    description: 'Pay when your order arrives',
  },
  {
    id: 'upi',
    label: 'UPI Payment',
    type: 'upi',
    icon: 'smartphone',
    description: 'Pay via Google Pay, PhonePe, Paytm',
    gateway: 'razorpay',
  },
  {
    id: 'card',
    label: 'Credit / Debit Card',
    type: 'card',
    icon: 'credit-card',
    description: 'Visa, Mastercard, RuPay',
    gateway: 'stripe',
  },
  {
    id: 'wallet',
    label: 'Online Wallet',
    type: 'wallet',
    icon: 'wallet',
    description: 'Paytm, Freecharge, Mobikwik',
    gateway: 'razorpay',
  },
];

/**
 * Process payment - currently a mock.
 * Replace with actual gateway SDK calls when integrating.
 * 
 * For Razorpay: Use razorpay.createOrder() + razorpay.checkout
 * For Stripe: Use stripe.paymentIntents.create()
 * For PayPal: Use paypal.orders.create()
 */
export async function processPayment(params: {
  amount: number;
  method: string;
  orderId: string;
  userId: string;
}): Promise<{ success: boolean; transactionId: string }> {
  // Mock payment processing - simulate a delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  // In production, this would call the actual payment gateway
  return {
    success: true,
    transactionId: `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
  };
}

/**
 * Verify payment status - mock implementation
 */
export async function verifyPayment(transactionId: string): Promise<boolean> {
  // In production, verify with the payment gateway
  return true;
}
