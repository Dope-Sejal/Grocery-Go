/**
 * User API Layer — calls edge functions instead of direct DB access.
 * Auth operations still use Supabase Auth client directly (client-side auth is standard).
 */

import { supabase } from '@/integrations/supabase/client';
import { apiGet } from './apiClient';
import { UserProfile } from './types';

export async function signUp(email: string, password: string, name: string) {
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { name }, emailRedirectTo: window.location.origin },
  });
  if (error) throw error;
}

export async function signIn(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentSession() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

export async function fetchAllProfiles(): Promise<UserProfile[]> {
  return apiGet<UserProfile[]>('api-users', { action: 'all' });
}

export async function checkUserRole(userId: string, role: 'admin' | 'user'): Promise<boolean> {
  const data = await apiGet<{ hasRole: boolean }>('api-users', { action: 'check_role', role, user_id: userId });
  return data.hasRole;
}
