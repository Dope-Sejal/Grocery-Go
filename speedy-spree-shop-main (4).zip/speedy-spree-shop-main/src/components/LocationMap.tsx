import { useEffect, useRef, useState, useCallback } from 'react';
import { MapPin, Search, Loader2, Navigation } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface LocationMapProps {
  onLocationSelect: (address: {
    full_address: string;
    city: string;
    state: string;
    zip_code: string;
    lat: number;
    lng: number;
  }) => void;
}

interface Suggestion {
  display_name: string;
  lat: string;
  lon: string;
  address: Record<string, string>;
}

export function LocationMap({ onLocationSelect }: LocationMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const [search, setSearch] = useState('');
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searching, setSearching] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    const initMap = async () => {
      const L = (await import('leaflet')).default;
      await import('leaflet/dist/leaflet.css');

      if (!mapRef.current || mapInstanceRef.current) return;

      delete (L.Icon.Default.prototype as any)._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
      });

      const map = L.map(mapRef.current).setView([20.5937, 78.9629], 5);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
      }).addTo(map);

      const marker = L.marker([20.5937, 78.9629], { draggable: true }).addTo(map);

      marker.on('dragend', async () => {
        const pos = marker.getLatLng();
        await reverseGeocode(pos.lat, pos.lng);
      });

      map.on('click', async (e: any) => {
        marker.setLatLng(e.latlng);
        await reverseGeocode(e.latlng.lat, e.latlng.lng);
      });

      mapInstanceRef.current = map;
      markerRef.current = marker;
      setLoaded(true);

      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const { latitude, longitude } = position.coords;
            map.setView([latitude, longitude], 15);
            marker.setLatLng([latitude, longitude]);
            await reverseGeocode(latitude, longitude);
          },
          () => {}
        );
      }
    };

    initMap();

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  const reverseGeocode = async (lat: number, lng: number) => {
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`
      );
      const data = await res.json();
      const addr = data.address || {};

      onLocationSelect({
        full_address: data.display_name || '',
        city: addr.city || addr.town || addr.village || addr.county || '',
        state: addr.state || '',
        zip_code: addr.postcode || '',
        lat,
        lng,
      });
      setSearch(data.display_name || '');
      setShowSuggestions(false);
    } catch {
      // silently fail
    }
  };

  const fetchSuggestions = useCallback(async (query: string) => {
    if (query.length < 3) {
      setSuggestions([]);
      return;
    }
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&addressdetails=1`
      );
      const results = await res.json();
      setSuggestions(results);
      setShowSuggestions(results.length > 0);
    } catch {
      setSuggestions([]);
    }
  }, []);

  const handleInputChange = (value: string) => {
    setSearch(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => fetchSuggestions(value), 400);
  };

  const selectSuggestion = (suggestion: Suggestion) => {
    const latNum = parseFloat(suggestion.lat);
    const lngNum = parseFloat(suggestion.lon);
    const addr = suggestion.address || {};

    if (mapInstanceRef.current && markerRef.current) {
      mapInstanceRef.current.setView([latNum, lngNum], 16);
      markerRef.current.setLatLng([latNum, lngNum]);
    }

    onLocationSelect({
      full_address: suggestion.display_name || '',
      city: addr.city || addr.town || addr.village || addr.county || '',
      state: addr.state || '',
      zip_code: addr.postcode || '',
      lat: latNum,
      lng: lngNum,
    });

    setSearch(suggestion.display_name);
    setShowSuggestions(false);
  };

  const handleLocateMe = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          if (mapInstanceRef.current && markerRef.current) {
            mapInstanceRef.current.setView([latitude, longitude], 16);
            markerRef.current.setLatLng([latitude, longitude]);
          }
          await reverseGeocode(latitude, longitude);
        },
        () => {}
      );
    }
  };

  return (
    <div className="space-y-3">
      {/* Search with autocomplete */}
      <div className="relative">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search for your area, street name..."
              value={search}
              onChange={(e) => handleInputChange(e.target.value)}
              onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              className="pl-10 text-sm"
            />
          </div>
          <Button type="button" size="sm" variant="outline" onClick={handleLocateMe} className="gap-1 shrink-0">
            <Navigation className="h-3.5 w-3.5" />
            <span className="hidden sm:inline text-xs">Locate me</span>
          </Button>
        </div>

        {/* Suggestions dropdown */}
        {showSuggestions && (
          <div className="absolute z-50 top-full mt-1 w-full bg-card border rounded-xl shadow-lg overflow-hidden animate-scale-in">
            {suggestions.map((s, i) => (
              <button
                key={i}
                className="w-full flex items-start gap-2 px-3 py-2.5 text-left hover:bg-muted/50 transition-colors text-sm border-b last:border-0"
                onMouseDown={() => selectSuggestion(s)}
              >
                <MapPin className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span className="text-xs leading-tight line-clamp-2">{s.display_name}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Map */}
      <div
        ref={mapRef}
        className="h-[220px] rounded-xl border overflow-hidden bg-muted"
        style={{ zIndex: 0 }}
      />

      <p className="text-[11px] text-muted-foreground flex items-center gap-1">
        <MapPin className="h-3 w-3" />
        Click on the map or drag the marker to set delivery location
      </p>
    </div>
  );
}
