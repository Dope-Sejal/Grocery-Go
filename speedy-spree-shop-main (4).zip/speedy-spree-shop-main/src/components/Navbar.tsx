import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Search, User, LogOut, Package, LayoutDashboard, Menu, X, UserCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/hooks/useCart';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function Navbar() {
  const { user, isAdmin, signOut } = useAuth();
  const { totalItems } = useCart();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/products?search=${encodeURIComponent(search.trim())}`);
      setSearch('');
      setSearchOpen(false);
      setMobileOpen(false);
    }
  };

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-card/85 backdrop-blur-2xl border-b border-border/50 shadow-card'
          : 'bg-transparent'
      }`}
    >
      <div className="container flex h-16 items-center gap-6">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5 shrink-0 group">
          <div className="h-9 w-9 rounded-xl gradient-primary flex items-center justify-center shadow-sm transition-transform duration-300 group-hover:scale-110 group-hover:shadow-glow">
            <span className="text-primary-foreground text-lg">🥬</span>
          </div>
          <span className="font-display font-bold text-xl hidden sm:block tracking-tight">
            Grocery<span className="gradient-text">Go</span>
          </span>
        </Link>

        {/* Search */}
        <div className="flex-1 max-w-lg hidden md:flex mx-auto">
          <form onSubmit={handleSearch} className="relative w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/60" />
            <Input
              placeholder="Search for fruits, vegetables, snacks..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onFocus={() => setSearchOpen(true)}
              onBlur={() => setSearchOpen(false)}
              className={`pl-11 h-10 bg-muted/50 border-border/40 rounded-full text-sm transition-all duration-300 ${
                searchOpen ? 'ring-2 ring-primary/30 bg-card shadow-elevated' : 'hover:bg-muted/70'
              }`}
            />
          </form>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 ml-auto">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2 text-xs font-semibold hover:bg-muted/50 rounded-full px-3">
                  <div className="h-7 w-7 rounded-full gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground shadow-sm">
                    {(user.email?.[0] || 'U').toUpperCase()}
                  </div>
                  <span className="hidden sm:inline text-muted-foreground">Account</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52 rounded-xl shadow-luxury p-1.5">
                <DropdownMenuItem onClick={() => navigate('/account')} className="rounded-lg">
                  <UserCircle className="mr-2.5 h-4 w-4 text-muted-foreground" /> My Account
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/orders')} className="rounded-lg">
                  <Package className="mr-2.5 h-4 w-4 text-muted-foreground" /> Orders
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem onClick={() => navigate('/admin')} className="rounded-lg">
                    <LayoutDashboard className="mr-2.5 h-4 w-4 text-muted-foreground" /> Dashboard
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator className="my-1" />
                <DropdownMenuItem onClick={() => signOut()} className="rounded-lg text-destructive">
                  <LogOut className="mr-2.5 h-4 w-4" /> Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button variant="ghost" size="sm" className="text-xs font-semibold gap-1.5 rounded-full hover:bg-muted/50" onClick={() => navigate('/login')}>
              <User className="h-4 w-4" /> Sign In
            </Button>
          )}

          <Link to="/cart">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button size="sm" className="relative gap-2 gradient-primary hover:shadow-glow rounded-full h-10 px-5 text-primary-foreground shadow-sm border-0 font-bold">
                <ShoppingBag className="h-4 w-4" />
                {totalItems > 0 ? (
                  <motion.span key={totalItems} initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-xs font-bold">
                    {totalItems}
                  </motion.span>
                ) : (
                  <span className="text-xs hidden sm:inline font-semibold">Cart</span>
                )}
              </Button>
            </motion.div>
          </Link>

          <Button variant="ghost" size="icon" className="md:hidden h-10 w-10 rounded-full hover:bg-muted/50" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Search */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }} className="md:hidden border-t overflow-hidden bg-card/90 backdrop-blur-xl">
            <div className="p-4">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/60" />
                  <Input placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-11 h-10 rounded-full bg-muted/40 text-sm" />
                </div>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
