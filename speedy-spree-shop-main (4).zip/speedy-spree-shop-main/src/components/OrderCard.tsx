import { useState } from 'react';
import { Package, X, Clock, CheckCircle, Truck, XCircle, Trash2, ChevronDown, ChevronUp, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { OrderTracker } from '@/components/OrderTracker';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const statusConfig: Record<string, { icon: React.ReactNode; color: string }> = {
  pending: { icon: <Clock className="h-4 w-4" />, color: 'bg-warning/10 text-warning border-warning/20' },
  confirmed: { icon: <CheckCircle className="h-4 w-4" />, color: 'bg-info/10 text-info border-info/20' },
  processing: { icon: <Package className="h-4 w-4" />, color: 'bg-info/10 text-info border-info/20' },
  shipped: { icon: <Truck className="h-4 w-4" />, color: 'bg-primary/10 text-primary border-primary/20' },
  delivered: { icon: <CheckCircle className="h-4 w-4" />, color: 'bg-success/10 text-success border-success/20' },
  cancelled: { icon: <XCircle className="h-4 w-4" />, color: 'bg-destructive/10 text-destructive border-destructive/20' },
};

interface OrderCardProps {
  order: {
    id: string;
    total_price: number;
    order_status: string;
    payment_status: string;
    payment_method: string | null;
    tracking_status?: string;
    created_at: string;
    order_items: { product_name: string; product_price: number; quantity: number }[];
  };
  onCancel?: (id: string) => void;
  onDelete?: (id: string) => void;
  isCancelling?: boolean;
}

export function OrderCard({ order, onCancel, onDelete, isCancelling }: OrderCardProps) {
  const [showTracking, setShowTracking] = useState(false);
  const status = statusConfig[order.order_status] || statusConfig.pending;
  const canDelete = ['delivered', 'cancelled'].includes(order.order_status);

  return (
    <div className="rounded-2xl border bg-card p-4 space-y-3 shadow-card hover:shadow-lg transition-shadow duration-300">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-muted-foreground font-mono">#{order.id.slice(0, 8)}</p>
          <p className="text-[10px] text-muted-foreground">{new Date(order.created_at).toLocaleDateString()}</p>
        </div>
        <Badge variant="outline" className={`gap-1 ${status.color}`}>
          {status.icon}
          {order.order_status}
        </Badge>
      </div>

      <div className="space-y-1">
        {order.order_items?.map((item, i) => (
          <div key={i} className="flex justify-between text-sm">
            <span>{item.product_name} x{item.quantity}</span>
            <span className="text-muted-foreground">₹{(item.product_price * item.quantity).toFixed(2)}</span>
          </div>
        ))}
      </div>

      {/* Order Tracking */}
      {order.order_status !== 'cancelled' && (
        <div>
          <button
            onClick={() => setShowTracking(!showTracking)}
            className="flex items-center gap-1.5 text-xs text-primary font-semibold hover:underline"
          >
            {showTracking ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            {showTracking ? 'Hide Tracking' : 'Track Order'}
          </button>
          {showTracking && (
            <div className="mt-3 p-3 bg-muted/30 rounded-xl animate-fade-in">
              <OrderTracker
                trackingStatus={order.tracking_status || 'order_placed'}
                orderStatus={order.order_status}
              />
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between pt-2 border-t">
        <span className="font-display font-bold">₹{Number(order.total_price).toFixed(2)}</span>
        <div className="flex gap-2">
          {order.order_status === 'pending' && onCancel && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" className="rounded-lg" disabled={isCancelling}>
                  {isCancelling ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <X className="h-3 w-3 mr-1" />}
                  {isCancelling ? 'Cancelling...' : 'Cancel'}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure you want to cancel this order?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will cancel your order #{order.id.slice(0, 8)}. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>No, Keep Order</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => onCancel(order.id)}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Yes, Cancel Order
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          {canDelete && onDelete && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive rounded-lg">
                  <Trash2 className="h-3 w-3 mr-1" /> Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Order</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to remove this order from your history? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onDelete(order.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </div>
    </div>
  );
}
