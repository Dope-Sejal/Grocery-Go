import { CheckCircle, Package, ChefHat, Bike, Home, Circle } from 'lucide-react';

const TRACKING_STEPS = [
  { key: 'order_placed', label: 'Order Placed', icon: CheckCircle, description: 'Your order has been confirmed' },
  { key: 'getting_ready', label: 'Getting Ready', icon: ChefHat, description: 'Items are being packed' },
  { key: 'picked_up', label: 'Picked Up', icon: Package, description: 'Delivery partner picked your order' },
  { key: 'out_for_delivery', label: 'Out for Delivery', icon: Bike, description: 'On the way to you' },
  { key: 'delivered', label: 'Delivered', icon: Home, description: 'Order delivered successfully' },
];

interface OrderTrackerProps {
  trackingStatus: string;
  orderStatus: string;
}

export function OrderTracker({ trackingStatus, orderStatus }: OrderTrackerProps) {
  if (orderStatus === 'cancelled') {
    return (
      <div className="flex items-center gap-2 p-3 rounded-xl bg-destructive/10 border border-destructive/20">
        <Circle className="h-4 w-4 text-destructive" />
        <span className="text-xs font-semibold text-destructive">Order Cancelled</span>
      </div>
    );
  }

  const currentIndex = TRACKING_STEPS.findIndex(s => s.key === trackingStatus);
  const activeIdx = currentIndex >= 0 ? currentIndex : 0;

  return (
    <div className="space-y-1">
      {TRACKING_STEPS.map((step, i) => {
        const isCompleted = i <= activeIdx;
        const isCurrent = i === activeIdx;
        const Icon = step.icon;

        return (
          <div key={step.key} className="flex items-start gap-3">
            {/* Line + Icon */}
            <div className="flex flex-col items-center">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center transition-all duration-500 ${
                isCompleted
                  ? isCurrent
                    ? 'gradient-primary text-primary-foreground shadow-glow animate-pulse-glow'
                    : 'bg-primary/20 text-primary'
                  : 'bg-muted text-muted-foreground'
              }`}>
                <Icon className="h-4 w-4" />
              </div>
              {i < TRACKING_STEPS.length - 1 && (
                <div className={`w-0.5 h-6 transition-colors duration-500 ${i < activeIdx ? 'bg-primary/40' : 'bg-muted'}`} />
              )}
            </div>
            {/* Text */}
            <div className="pt-1">
              <p className={`text-xs font-semibold ${isCompleted ? 'text-foreground' : 'text-muted-foreground'}`}>
                {step.label}
              </p>
              <p className="text-[10px] text-muted-foreground">{step.description}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
