import { Link } from 'react-router-dom';
import { Plus, Minus, Zap, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/hooks/useCart';
import { useNavigate } from 'react-router-dom';
import { getDefaultImage } from '@/lib/defaultImages';
import { motion } from 'framer-motion';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  discount?: number;
  image: string | null;
  unit: string | null;
  stock: number;
  categoryName?: string;
  isBestSeller?: boolean;
  isDealOfDay?: boolean;
}

export function ProductCard({ id, name, price, discount = 0, image, unit, stock, categoryName, isBestSeller, isDealOfDay }: ProductCardProps) {
  const { user } = useAuth();
  const { cartItems, addToCart, updateQuantity } = useCart();
  const navigate = useNavigate();
  const cartItem = cartItems.find(item => item.product_id === id);
  const inCart = !!cartItem;
  const finalPrice = discount > 0 ? price - (price * discount / 100) : price;
  const displayImage = image || getDefaultImage(categoryName);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    if (!user) { navigate('/login'); return; }
    if (inCart) { updateQuantity.mutate({ itemId: cartItem!.id, quantity: cartItem!.quantity + 1 }); }
    else { addToCart.mutate({ productId: id }); }
  };

  const handleDecrement = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    if (cartItem) updateQuantity.mutate({ itemId: cartItem.id, quantity: cartItem.quantity - 1 });
  };

  return (
    <Link to={`/products/${id}`} className="group block">
      <motion.div
        whileHover={{ y: -5 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col rounded-2xl bg-card overflow-hidden shadow-card hover:shadow-elevated transition-all duration-500 border border-border/40 relative"
      >
        {/* Top accent */}
        <div className="absolute top-0 left-0 right-0 h-1 gradient-fresh rounded-t-2xl" />

        {/* Image */}
        <div className="relative bg-gradient-to-br from-lime-soft/60 to-yellow-soft/40 p-4 flex items-center justify-center overflow-hidden aspect-square">
          <img src={displayImage} alt={name} className="h-full w-full object-contain group-hover:scale-110 transition-transform duration-700 ease-out" loading="lazy" />

          {/* Badges */}
          <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5">
            {discount > 0 && (
              <span className="inline-flex items-center gap-1 gradient-warm text-secondary-foreground text-[10px] font-bold rounded-full px-2.5 py-1 shadow-sm">
                <Zap className="h-2.5 w-2.5" /> {discount}% OFF
              </span>
            )}
            {isBestSeller && (
              <span className="inline-flex items-center gap-1 gradient-sunny text-secondary-foreground text-[10px] font-bold rounded-full px-2.5 py-1 shadow-sm">
                <Star className="h-2.5 w-2.5" /> Best
              </span>
            )}
            {isDealOfDay && !isBestSeller && (
              <span className="inline-flex items-center gap-1 gradient-primary text-primary-foreground text-[10px] font-bold rounded-full px-2.5 py-1 shadow-sm">
                <Zap className="h-2.5 w-2.5" /> Deal
              </span>
            )}
          </div>

          {stock <= 0 && (
            <div className="absolute inset-0 bg-background/70 backdrop-blur-sm flex items-center justify-center">
              <span className="text-xs font-semibold text-muted-foreground bg-card px-5 py-2 rounded-full shadow-sm">Sold Out</span>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-4 flex flex-col gap-1 flex-1">
          <span className="text-[10px] uppercase tracking-[0.15em] text-primary font-semibold">{categoryName || 'Grocery'}</span>
          <h3 className="font-display font-bold text-sm leading-snug line-clamp-2 min-h-[2.25rem] group-hover:text-primary transition-colors duration-300">{name}</h3>
          <span className="text-[11px] text-muted-foreground">{unit || 'pc'}</span>

          <div className="flex items-center justify-between mt-auto pt-3">
            <div className="flex items-baseline gap-1.5">
              <span className="font-display font-bold text-lg text-foreground">₹{Math.round(finalPrice)}</span>
              {discount > 0 && <span className="text-[11px] text-muted-foreground line-through">₹{price}</span>}
            </div>
            {stock > 0 && (
              inCart ? (
                <div className="flex items-center rounded-full overflow-hidden gradient-primary shadow-sm">
                  <button onClick={handleDecrement} className="px-3 py-1.5 hover:bg-primary-foreground/10 transition-colors">
                    <Minus className="h-3 w-3 text-primary-foreground" />
                  </button>
                  <motion.span key={cartItem!.quantity} initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="w-6 text-center text-xs font-bold text-primary-foreground">
                    {cartItem!.quantity}
                  </motion.span>
                  <button onClick={handleAdd} className="px-3 py-1.5 hover:bg-primary-foreground/10 transition-colors">
                    <Plus className="h-3 w-3 text-primary-foreground" />
                  </button>
                </div>
              ) : (
                <Button size="sm" className="h-8 text-xs px-5 gradient-primary text-primary-foreground font-semibold rounded-full transition-all duration-300 shadow-sm hover:shadow-glow border-0" onClick={handleAdd}>
                  Add
                </Button>
              )
            )}
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
