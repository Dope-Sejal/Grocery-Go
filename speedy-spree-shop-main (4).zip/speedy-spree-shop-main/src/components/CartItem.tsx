import { useState } from 'react';
import { Plus, Minus, Trash2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CartItemWithProduct } from '@/hooks/useCart';

interface CartItemProps {
  item: CartItemWithProduct;
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  onRemove: (itemId: string) => void;
}

export function CartItemComponent({ item, onUpdateQuantity, onRemove }: CartItemProps) {
  const [isUpdating, setIsUpdating] = useState(false);
  const product = item.products;
  if (!product) return null;

  const handleQuantityChange = async (newQty: number) => {
    if (newQty < 1 || isUpdating) return;
    setIsUpdating(true);
    try {
      onUpdateQuantity(item.id, newQty);
    } finally {
      // Reset after a short delay to allow mutation to process
      setTimeout(() => setIsUpdating(false), 600);
    }
  };

  return (
    <div className="flex gap-3 py-3 border-b last:border-0">
      <div className="h-16 w-16 rounded-xl bg-muted/20 flex items-center justify-center shrink-0 overflow-hidden border">
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-contain p-1"
            onError={(e) => { (e.target as HTMLImageElement).src = '/placeholder.svg'; }}
          />
        ) : (
          <span className="text-2xl">🛒</span>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-xs truncate">{product.name}</h3>
        <p className="text-[10px] text-muted-foreground mt-0.5">{product.unit || 'pc'}</p>
        <div className="flex items-center justify-between mt-1.5">
          <span className="font-display font-bold text-sm">₹{(product.price * item.quantity).toFixed(2)}</span>
          <div className="flex items-center gap-1">
            <div className="flex items-center rounded-lg border border-primary bg-primary/5 overflow-hidden">
              <button
                className="px-2 py-1 hover:bg-primary/10 transition-colors disabled:opacity-40"
                disabled={item.quantity <= 1 || isUpdating}
                onClick={() => handleQuantityChange(item.quantity - 1)}
              >
                {isUpdating ? <Loader2 className="h-3 w-3 text-primary animate-spin" /> : <Minus className="h-3 w-3 text-primary" />}
              </button>
              <span className="w-6 text-center text-xs font-bold text-primary">{item.quantity}</span>
              <button
                className="px-2 py-1 hover:bg-primary/10 transition-colors disabled:opacity-40"
                disabled={isUpdating}
                onClick={() => handleQuantityChange(item.quantity + 1)}
              >
                {isUpdating ? <Loader2 className="h-3 w-3 text-primary animate-spin" /> : <Plus className="h-3 w-3 text-primary" />}
              </button>
            </div>
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 text-destructive hover:text-destructive ml-0.5"
              onClick={() => onRemove(item.id)}
              disabled={isUpdating}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
