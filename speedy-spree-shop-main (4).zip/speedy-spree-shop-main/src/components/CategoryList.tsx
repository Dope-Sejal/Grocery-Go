import { Link } from 'react-router-dom';
import { useCategories } from '@/hooks/useProducts';
import { Skeleton } from '@/components/ui/skeleton';
import { categoryEmojis } from '@/lib/defaultImages';
import { motion } from 'framer-motion';

const cardStyles = [
  'from-green/12 to-green-light/12 border-green/20 hover:shadow-[0_8px_30px_-8px_hsl(145,65%,32%,0.3)]',
  'from-yellow/12 to-yellow-light/12 border-yellow/20 hover:shadow-[0_8px_30px_-8px_hsl(48,96%,53%,0.3)]',
  'from-lime/12 to-lime-light/12 border-lime/20 hover:shadow-[0_8px_30px_-8px_hsl(80,65%,50%,0.3)]',
  'from-orange/12 to-orange-light/12 border-orange/20 hover:shadow-[0_8px_30px_-8px_hsl(30,90%,55%,0.3)]',
  'from-teal/12 to-teal-light/12 border-teal/20 hover:shadow-[0_8px_30px_-8px_hsl(170,55%,38%,0.3)]',
  'from-pink/10 to-pink-light/10 border-pink/20 hover:shadow-[0_8px_30px_-8px_hsl(340,70%,58%,0.3)]',
  'from-gold/12 to-gold-light/12 border-gold/20 hover:shadow-[0_8px_30px_-8px_hsl(42,75%,52%,0.3)]',
  'from-ocean/10 to-ocean-light/10 border-ocean/20 hover:shadow-[0_8px_30px_-8px_hsl(200,70%,50%,0.3)]',
];

const iconBgs = [
  'bg-green/15', 'bg-yellow/15', 'bg-lime/15', 'bg-orange/15',
  'bg-teal/15', 'bg-pink/12', 'bg-gold/15', 'bg-ocean/12',
];

export function CategoryList() {
  const { data: categories, isLoading } = useCategories();

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-32 rounded-2xl" />)}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-4">
      {categories?.map((cat, i) => (
        <motion.div key={cat.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05, duration: 0.5, ease: 'easeOut' }}>
          <Link
            to={`/products?category=${cat.id}`}
            className={`flex flex-col items-center gap-3 p-5 rounded-2xl bg-gradient-to-br border transition-all duration-500 group cursor-pointer ${cardStyles[i % cardStyles.length]}`}
          >
            <div className={`h-14 w-14 rounded-2xl flex items-center justify-center ${iconBgs[i % iconBgs.length]} group-hover:scale-110 transition-transform duration-500`}>
              {cat.image ? (
                <img src={cat.image} alt={cat.name} className="h-10 w-10 object-cover rounded-xl" />
              ) : (
                <span className="text-3xl">{categoryEmojis[cat.name] || '🛒'}</span>
              )}
            </div>
            <span className="text-sm font-semibold text-center leading-tight text-foreground/80 group-hover:text-foreground transition-colors duration-300">
              {cat.name}
            </span>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}
