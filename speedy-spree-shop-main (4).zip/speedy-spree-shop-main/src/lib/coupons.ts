export interface Coupon {
  code: string;
  discountPercent: number;
  description: string;
  minOrderAmount: number;
  maxDiscount: number;
}

export const AVAILABLE_COUPONS: Coupon[] = [
  {
    code: 'SAVE10',
    discountPercent: 10,
    description: '10% off on your order',
    minOrderAmount: 200,
    maxDiscount: 100,
  },
  {
    code: 'WELCOME20',
    discountPercent: 20,
    description: '20% off for new users',
    minOrderAmount: 300,
    maxDiscount: 200,
  },
];

export function applyCoupon(code: string, orderTotal: number): { valid: boolean; discount: number; message: string } {
  const coupon = AVAILABLE_COUPONS.find(c => c.code === code.toUpperCase().trim());
  
  if (!coupon) {
    return { valid: false, discount: 0, message: 'Invalid coupon code' };
  }

  if (orderTotal < coupon.minOrderAmount) {
    return { valid: false, discount: 0, message: `Minimum order ₹${coupon.minOrderAmount} required` };
  }

  const rawDiscount = (orderTotal * coupon.discountPercent) / 100;
  const discount = Math.min(rawDiscount, coupon.maxDiscount);

  return { valid: true, discount, message: `${coupon.description} — you save ₹${Math.round(discount)}!` };
}
