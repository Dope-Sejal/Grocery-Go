/**
 * Default product images by category.
 * Uses free Unsplash images that match each category.
 * When admin adds a product without an image, the system auto-assigns one.
 */

const categoryImages: Record<string, string> = {
  'Fruits': 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=400&h=400&fit=crop',
  'Vegetables': 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=400&fit=crop',
  'Fruits & Vegetables': 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=400&h=400&fit=crop',
  'Dairy': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
  'Bakery': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=400&fit=crop',
  'Snacks': 'https://images.unsplash.com/photo-1621939514649-280e2ee25f60?w=400&h=400&fit=crop',
  'Beverages': 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=400&fit=crop',
  'Meat & Seafood': 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&h=400&fit=crop',
  'Frozen Foods': 'https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?w=400&h=400&fit=crop',
  'Pantry': 'https://images.unsplash.com/photo-1584473457406-6240486418e9?w=400&h=400&fit=crop',
  'Personal Care': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
  'Household': 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=400&h=400&fit=crop',
};

const fallbackImage = 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=400&fit=crop';

export function getDefaultImage(categoryName?: string | null): string {
  if (!categoryName) return fallbackImage;
  return categoryImages[categoryName] || fallbackImage;
}

export const categoryEmojis: Record<string, string> = {
  'Fruits': '🍎',
  'Vegetables': '🥬',
  'Fruits & Vegetables': '🥕',
  'Dairy': '🥛',
  'Bakery': '🍞',
  'Snacks': '🍿',
  'Beverages': '🥤',
  'Meat & Seafood': '🥩',
  'Frozen Foods': '🧊',
  'Pantry': '🫙',
  'Personal Care': '🧴',
  'Household': '🏠',
};
